"""Offline regression suite: external requests and real OpenAI clients are forbidden."""
import contextlib
import http.client
import io
import json
import os
from pathlib import Path
import tempfile
import threading
import unittest
from unittest.mock import Mock, patch
from urllib.parse import urlencode

_BOOT = tempfile.TemporaryDirectory()
os.environ['SECHA_BASE_DIR'] = _BOOT.name
import secha_engine as e
import assistant_tools as a
import app


class StudioFixture:
    def setUp(self):
        self.tmp = tempfile.TemporaryDirectory()
        self.addCleanup(self.tmp.cleanup)
        self.root = Path(self.tmp.name)
        self.stack = contextlib.ExitStack()
        self.addCleanup(self.stack.close)
        for target, value in [('secha_engine.BASE_DIR', self.root),
                              ('secha_engine.HISTORY_PATH', self.root/'topic_history.json'),
                              ('secha_engine.EXISTING_TITLES_PATH', self.root/'existing_blog_titles.txt'),
                              ('app.BASE', self.root), ('secha_engine.OPENAI_KEY', None)]:
            self.stack.enter_context(patch(target, value))
        for target in ('secha_engine.OpenAI', 'assistant_tools.OpenAI', 'requests.sessions.Session.request'):
            self.stack.enter_context(patch(target, side_effect=AssertionError('REAL EXTERNAL API FORBIDDEN')))
        app.LOCK = threading.Lock()
        app.STATE.update(busy=False, log='', notice='준비', audit=None, chat=[])

    def run_folder(self, status='REVIEW_CANDIDATE'):
        p = self.root/'output'/'sample'
        p.mkdir(parents=True)
        (p/'review_report.json').write_text(json.dumps({'topic':'자동차 타이어 관리', 'status':status}), encoding='utf-8')
        (p/'blog_post.txt').write_text('기존 원고 보존',encoding='utf-8-sig')
        return p

    def client(self, text):
        client = Mock()
        client.responses.create.return_value.output_text = text
        return client

class StudioTests(StudioFixture, unittest.TestCase):
    def test_history_bom_and_merge_preserves_previous(self):
        e.HISTORY_PATH.write_text('["기존"]',encoding='utf-8-sig')
        e.save_history(['새 글'])
        self.assertEqual(e.load_history(), ['기존','새 글'])

    def test_corrupt_history_not_overwritten(self):
        e.HISTORY_PATH.write_text('BROKEN',encoding='utf-8')
        with self.assertRaises(ValueError): e.save_history(['새 글'])
        self.assertEqual(e.HISTORY_PATH.read_text(), 'BROKEN')

    def test_invalid_history_not_written(self):
        with self.assertRaises(ValueError): e.save_history([123])
        self.assertFalse(e.HISTORY_PATH.exists())

    def test_path_traversal(self):
        self.run_folder()
        for name in ('..', '.', '../sample', '..\\sample', 'C:secret', ''):
            with self.subTest(name=name), self.assertRaises(ValueError): a.safe_run(self.root,name)

    def test_file_allowlist(self):
        self.run_folder()
        for name in ('.env', '..', 'other.json', '../.env'):
            with self.subTest(name=name), self.assertRaises(ValueError): a.safe_file(self.root,'sample',name)

    def test_symlink_escape(self):
        p=self.run_folder()
        target=self.root/'private.txt';target.write_text('private')
        (p/'blog_post.txt').unlink()
        try:(p/'blog_post.txt').symlink_to(target)
        except OSError:self.skipTest('symlink creation unavailable')
        with self.assertRaises(ValueError): a.safe_file(self.root,'sample','blog_post.txt')

    def test_output_symlink_rejected(self):
        target=self.root/'other';target.mkdir()
        try:(self.root/'output').symlink_to(target,target_is_directory=True)
        except OSError:self.skipTest('symlink creation unavailable')
        (target/'sample').mkdir()
        with self.assertRaises(ValueError):a.safe_run(self.root,'sample')

    def test_ai_approval_required_before_client(self):
        with self.assertRaises(PermissionError): a.ask_ai('질문','상태')

    def test_ai_sensitive_question_blocked(self):
        with patch.object(e,'OPENAI_KEY','sk-exampleSecret123'):
            with self.assertRaises(ValueError):a.ask_ai('키 sk-exampleSecret123','',approved=True)

    def test_expert_schema_rejects_non_string_issue(self):
        for issue in (None, {}, 1, ''):
            with self.subTest(issue=issue), self.assertRaises(ValueError):
                e.expert_review(self.client(json.dumps({'pass':True,'issues':[issue],'needs_sources':False})), '주제','본문')

    def test_expert_not_json_fails_closed(self):
        with self.assertRaises(ValueError):e.expert_review(self.client('통과!'),'주제','본문')

    def test_review_failure_does_not_revise_or_leak_error(self):
        with patch.object(e,'comprehensive_review',side_effect=RuntimeError('sk-secret123456')), patch.object(e,'revise_article_for_safety') as revise:
            article,issues,logs=e.review_with_revisions(Mock(),'주제','원문')
        self.assertEqual(article,'원문');self.assertTrue(issues);revise.assert_not_called()
        self.assertNotIn('sk-secret',json.dumps(logs))

    def test_review_revision_then_pass(self):
        with patch.object(e,'comprehensive_review',side_effect=[['위험'],[]]), patch.object(e,'revise_article_for_safety',return_value='수정문'):
            article,issues,logs=e.review_with_revisions(Mock(),'주제','원문')
        self.assertEqual(article,'수정문');self.assertEqual(issues,[]);self.assertEqual(len(logs),2)

    def test_revision_exhaustion_hold(self):
        with patch.object(e,'comprehensive_review',return_value=['위험']),patch.object(e,'revise_article_for_safety',return_value='수정문') as revise:
            _,issues,logs=e.review_with_revisions(Mock(),'주제','원문')
        self.assertTrue(issues);self.assertEqual(revise.call_count,e.MAX_REVISIONS);self.assertEqual(len(logs),e.MAX_REVISIONS+1)

    def test_sources_required_blocks_pass(self):
        with patch.object(e,'validate_article',return_value=[]),patch.object(e,'domain_static_checks',return_value=[]),patch.object(e,'expert_review',return_value={'pass':True,'issues':[],'needs_sources':True}):
            self.assertTrue(e.comprehensive_review(Mock(),'주제','본문'))

    def test_hot_cap_warning_is_not_unsafe_recommendation(self):
        self.assertNotIn('뜨거운 냉각계통 캡 개방 표현 확인', e.domain_static_checks('과열','뜨거운 냉각수 캡을 열지 마세요. 제조사 매뉴얼을 확인하세요.'))
        self.assertIn('뜨거운 냉각계통 캡 개방 표현 확인', e.domain_static_checks('과열','뜨거운 냉각수 캡을 열어 확인합니다.'))

    def test_warning_topic_requires_safety_instructions(self):
        issues=e.validate_article('엔진오일 경고등', '계속 운전하세요. '*100)
        self.assertTrue(any('정차' in x for x in issues));self.assertTrue(any('견인' in x for x in issues))

    def test_vision_mime_and_invalid_content(self):
        c=self.client('ACCEPT');job=e.make_image_jobs('타이어')[0]
        self.assertFalse(e.verify_photo_with_vision(c,b'<html>',job));c.responses.create.assert_not_called()
        self.assertTrue(e.verify_photo_with_vision(c,b'RIFF1234WEBPdata',job))
        payload=c.responses.create.call_args.kwargs['input'][0]['content'][1]['image_url']
        self.assertTrue(payload.startswith('data:image/webp;'))

    def test_vision_uncertain_rejected(self):
        self.assertFalse(e.verify_photo_with_vision(self.client('ACCEPT maybe'),b'\xff\xd8\xffdata',e.make_image_jobs('타이어')[0]))

    def test_duplicate_rejected_photo_not_rebilled(self):
        job=e.make_image_jobs('타이어')[0];job['queries']=['first','second']
        photo={'id':1,'tags':'car tire wheel','webformatURL':'https://example.com/a.jpg'}
        r=Mock(content=b'\xff\xd8\xffdata',headers={'Content-Type':'image/jpeg'})
        with patch.object(e,'search_pixabay',return_value=[photo]),patch.object(e.requests,'get',return_value=r),patch.object(e,'verify_photo_with_vision',return_value=False) as vision:
            self.assertIsNone(e.save_pixabay_image(Mock(),job,self.root,set()))
        self.assertEqual(vision.call_count,1)

    def test_query_failure_tries_next(self):
        job=e.make_image_jobs('타이어')[0];job['queries']=['first','second']
        with patch.object(e,'search_pixabay',side_effect=[e.requests.RequestException('secret'),[]]) as search:
            self.assertIsNone(e.save_pixabay_image(Mock(),job,self.root,set()))
        self.assertEqual(search.call_count,2)

    def test_retry_hold_does_not_call_api(self):
        self.run_folder('HOLD')
        with self.assertRaises(ValueError):a.image_retry(self.root,'sample',lambda _:None)

    def test_retry_preserves_manuscript_history_and_old_report(self):
        p=self.run_folder();e.save_history(['원래주제'])
        old=p/'image_retry_report.json';old.write_text('{"old":true}')
        before={f:f.read_bytes() for f in (p/'blog_post.txt',p/'review_report.json',old,e.HISTORY_PATH)}
        with patch.object(e,'OPENAI_KEY','test-only'),patch.object(a,'OpenAI',return_value=Mock()),patch.object(e,'save_pixabay_image',return_value=None),patch.object(e,'save_open_photo',return_value=None):
            a.image_retry(self.root,'sample',lambda _:None)
            a.image_retry(self.root,'sample',lambda _:None)
        for f,data in before.items():self.assertEqual(f.read_bytes(),data)
        reports=list(p.glob('image_retry_report_*.json'));self.assertEqual(len(reports),2)
        data=json.loads(reports[0].read_text());self.assertEqual(data['added'],0);self.assertEqual(len(data['diagnostics']),2)

    def test_retry_search_broadened_without_relaxing_criteria(self):
        self.run_folder()
        with patch.object(e,'OPENAI_KEY','test-only'),patch.object(a,'OpenAI',return_value=Mock()),patch.object(e,'save_pixabay_image',return_value=None) as pix,patch.object(e,'save_open_photo',return_value=None):
            a.image_retry(self.root,'sample',lambda _:None)
        job=pix.call_args_list[0].args[1]
        self.assertGreater(len(job['queries']),1)
        self.assertEqual(job['criteria'],e.make_image_jobs('자동차 타이어 관리')[0]['criteria'])

    def test_existing_image_not_overwritten(self):
        p=self.run_folder();d=p/'images';d.mkdir();f=d/'01_cover.jpg';f.write_bytes(b'original')
        with patch.object(e,'OPENAI_KEY','test-only'),patch.object(a,'OpenAI',return_value=Mock()),patch.object(e,'save_pixabay_image',return_value=None) as pix,patch.object(e,'save_open_photo',return_value=None):
            a.image_retry(self.root,'sample',lambda _:None)
        self.assertEqual(f.read_bytes(),b'original');self.assertEqual(pix.call_count,1)

    def test_free_commands_no_api_and_no_history_change(self):
        e.save_history(['기존']);before=e.HISTORY_PATH.read_bytes()
        with contextlib.redirect_stdout(io.StringIO()):answer=a.local_command('/진단',self.root)
        self.assertIn('무료 진단 완료',answer);self.assertTrue((self.root/'topic_audit.json').exists())
        self.assertIn('계획',a.local_command('/계획',self.root));self.assertEqual(e.HISTORY_PATH.read_bytes(),before)

    def test_retry_command_waits_for_approval(self):
        self.run_folder()
        with patch.object(a,'image_retry') as retry:
            self.assertIn('실행 대기',a.local_command('/사진재검색 sample',self.root))
        retry.assert_not_called()

    def test_generate_hold_keeps_draft_no_history(self):
        with patch.object(e,'OpenAI',return_value=Mock()),patch.object(e,'generate_article',return_value='원문'),patch.object(e,'review_with_revisions',return_value=('원문',['위험'],[])):
            self.assertFalse(e.generate_one('자동차 타이어 관리','타이어',[]))
        p=next((self.root/'output').iterdir())
        self.assertEqual(json.loads((p/'review_report.json').read_text())['status'],'HOLD')
        self.assertIn('원문',(p/'blog_post.txt').read_text(encoding='utf-8-sig'));self.assertFalse(e.HISTORY_PATH.exists())

    def test_generate_success_without_images_saves_draft_and_history(self):
        topic='자동차 과열 경고가 뜰 때 안전하게 대처하는 방법'
        with patch.object(e,'OpenAI',return_value=Mock()),patch.object(e,'generate_article',return_value='안전 원고 '*200),patch.object(e,'review_with_revisions',side_effect=lambda c,t,a:(a,[],[])),patch.object(e,'save_pixabay_image',return_value=None),patch.object(e,'save_open_photo',return_value=None),patch.object(e,'ALLOW_PAID_AI_IMAGES',False):
            self.assertTrue(e.generate_one(topic,'냉각수',[]))
        p=next((self.root/'output').iterdir());body=(p/'blog_post.txt').read_text(encoding='utf-8-sig')
        self.assertNotIn('[사진 1:',body);self.assertEqual(e.load_history(),[topic])
        self.assertEqual(json.loads((p/'review_report.json').read_text())['status'],'REVIEW_CANDIDATE')

    def test_persistent_journal(self):
        app.record('audit','완료')
        self.assertIn('audit',app.journal_text());self.assertNotIn('질문',app.journal_text())


    def test_history_active_writer_rejected_without_changes(self):
        e.save_history(['기존'])
        lock=e.HISTORY_PATH.with_suffix('.write.lock');lock.write_text('other writer')
        with self.assertRaises(FileExistsError):e.save_history(['새 글'])
        self.assertEqual(e.load_history(),['기존']);self.assertEqual(lock.read_text(),'other writer')

    def test_generation_failure_report_no_secret_or_history(self):
        with patch.object(e,'OpenAI',return_value=Mock()),patch.object(e,'generate_article',side_effect=RuntimeError('sk-secret123456')):
            self.assertFalse(e.generate_one('주제','키워드',[]))
        p=next((self.root/'output').iterdir());r=(p/'review_report.json').read_text()
        self.assertEqual(json.loads(r)['status'],'ERROR');self.assertNotIn('sk-secret',r)
        self.assertFalse(e.HISTORY_PATH.exists())

    def test_free_manuscript_review_preserves_files(self):
        p=self.run_folder();before=(p/'blog_post.txt').read_bytes()
        result=a.local_command('/원고검수 sample',self.root)
        self.assertIn('무료 규칙 검수',result);self.assertEqual((p/'blog_post.txt').read_bytes(),before)

    def test_missing_photo_analysis_reports_both_slots(self):
        self.run_folder()
        result=a.local_command('/사진분석 sample',self.root)
        self.assertIn('01_cover',result);self.assertIn('02_article',result)

    def test_photo_search_success_saves_credit(self):
        job=e.make_image_jobs('타이어')[0]
        photo={'id':3,'tags':'car tire wheel','webformatURL':'https://example.com/a.jpg','pageURL':'https://example.com/photo'}
        r=Mock(content=b'\xff\xd8\xfftest',headers={'Content-Type':'image/jpeg'})
        with patch.object(e,'search_pixabay',return_value=[photo]),patch.object(e.requests,'get',return_value=r),patch.object(e,'verify_photo_with_vision',return_value=True):
            selected=e.save_pixabay_image(Mock(),job,self.root,set())
        self.assertEqual((self.root/'01_cover.jpg').read_bytes(),r.content)
        self.assertEqual(selected['asset_id'],'Pixabay:3')

    def test_photo_helper_refuses_existing_file_overwrite(self):
        job=e.make_image_jobs('타이어')[0];f=self.root/'01_cover.jpg';f.write_bytes(b'original')
        photo={'id':3,'tags':'car tire wheel','webformatURL':'https://example.com/a.jpg'}
        r=Mock(content=b'\xff\xd8\xfftest',headers={'Content-Type':'image/jpeg'})
        with patch.object(e,'search_pixabay',return_value=[photo]),patch.object(e.requests,'get',return_value=r),patch.object(e,'verify_photo_with_vision',return_value=True):
            self.assertIsNone(e.save_pixabay_image(Mock(),job,self.root,set()))
        self.assertEqual(f.read_bytes(),b'original')

    def test_photo_vision_budget(self):
        job=e.make_image_jobs('타이어')[0]
        photos=[{'id':i,'tags':'car tire wheel','webformatURL':f'https://example.com/{i}.jpg'} for i in range(1,12)]
        r=Mock(content=b'\xff\xd8\xfftest',headers={'Content-Type':'image/jpeg'})
        with patch.object(e,'search_pixabay',return_value=photos),patch.object(e.requests,'get',return_value=r),patch.object(e,'verify_photo_with_vision',return_value=False) as vision:
            self.assertIsNone(e.save_pixabay_image(Mock(),job,self.root,set()))
        self.assertEqual(vision.call_count,e.MAX_VISION_CHECKS_PER_JOB)

    def test_openverse_failover_and_credit(self):
        job=e.make_image_jobs('타이어')[0];job['queries']=['first','second']
        item={'url':'https://example.com/photo.png','preview':'https://example.com/thumb.png','page':'https://example.com/credit','creator':'Author','license':'by','license_url':'https://example.com/license','title':'car'}
        r=Mock(content=b'\x89PNG\r\n\x1a\ndata',headers={'Content-Type':'image/png'})
        with patch.object(e,'search_openverse',side_effect=[e.requests.RequestException('private'),[item]]),patch.object(e.requests,'get',return_value=r),patch.object(e,'verify_photo_with_vision',return_value=True):
            selected=e.save_open_photo(Mock(),job,self.root,set(),'Openverse')
        self.assertEqual(selected['license'],'by');self.assertTrue((self.root/'01_cover.png').is_file())

    def test_openverse_rejects_noncommercial_license(self):
        response=Mock();response.json.return_value={'results':[{'license':'by-nc'},{'license':'by','url':'https://example.com/p.jpg'}]}
        with patch.object(e.requests,'get',return_value=response):result=e.search_openverse('car')
        self.assertEqual(len(result),1);self.assertEqual(result[0]['license'],'by')

    def test_retry_loads_previous_credit_ids(self):
        p=self.run_folder()
        (p/'image_retry_report.json').write_text(json.dumps({'sources':[{'asset_id':'Pixabay:5','asset_url':'https://example.com/a.jpg'}]}))
        with patch.object(e,'OPENAI_KEY','test-only'),patch.object(a,'OpenAI',return_value=Mock()),patch.object(e,'save_pixabay_image',return_value=None) as pix,patch.object(e,'save_open_photo',return_value=None):
            a.image_retry(self.root,'sample',lambda _:None)
        self.assertIn('Pixabay:5',pix.call_args.args[3]);self.assertIn('https://example.com/a.jpg',pix.call_args.args[3])

    def test_approved_ai_mock_redacts_summary(self):
        c=self.client('모의 응답')
        with patch.object(e,'OPENAI_KEY','sk-exampleSecret123'),patch.object(a,'OpenAI',return_value=c):
            self.assertEqual(a.ask_ai('정상 질문','오류 sk-exampleSecret123',approved=True),'모의 응답')
        self.assertNotIn('sk-exampleSecret123',c.responses.create.call_args.kwargs['input'])

    def test_chat_failure_releases_lock_and_no_secret_log(self):
        app.LOCK.acquire();app.STATE['busy']=True
        with patch.object(a,'ask_ai',side_effect=RuntimeError('sk-secret123456')):
            app.chat_worker('질문','상태')
        self.assertFalse(app.LOCK.locked());self.assertFalse(app.STATE['busy'])
        self.assertNotIn('sk-secret',app.journal_text())

    def test_live_log_redacts_known_keys(self):
        with patch.object(e,'OPENAI_KEY','sk-exampleSecret123'):
            log=app.LiveLog();log.write('오류 sk-exampleSecret123')
        self.assertNotIn('sk-exampleSecret123',app.STATE['log']);self.assertIn('숨김',app.STATE['log'])



    def test_all_topic_mappings_are_explicit_after_audit(self):
        with contextlib.redirect_stdout(io.StringIO()):audit=e.offline_topic_audit()
        self.assertEqual(audit['total_topics'],139)
        self.assertEqual(audit['remaining'],139)
        self.assertEqual(audit['flagged'],0)
        self.assertNotEqual(e.make_image_jobs('자동차 타이어 공기압 올바르게 관리하는 방법')[0]['queries'][0], 'car tire tread wheel')

    def test_full_download_invalid_image_not_saved(self):
        job=e.make_image_jobs('타이어')[0]
        photo={'id':3,'tags':'car tire wheel','webformatURL':'https://example.com/a.jpg'}
        preview=Mock(content=b'\xff\xd8\xffvalid',headers={'Content-Type':'image/jpeg'})
        full=Mock(content=b'<html>not image</html>',headers={'Content-Type':'image/jpeg'})
        with patch.object(e,'search_pixabay',return_value=[photo]),patch.object(e.requests,'get',side_effect=[preview,full]),patch.object(e,'verify_photo_with_vision',return_value=True):
            self.assertIsNone(e.save_pixabay_image(Mock(),job,self.root,set()))
        self.assertFalse((self.root/'01_cover.jpg').exists())

    def test_worker_saves_original_and_revised_drafts(self):
        with patch.object(e,'OpenAI',return_value=Mock()),patch.object(e,'generate_article',return_value='원문'),patch.object(e,'review_with_revisions',return_value=('수정문',['위험'],[])):
            e.generate_one('주제','키워드',[])
        p=next((self.root/'output').iterdir())
        self.assertEqual((p/'draft_original.txt').read_text(encoding='utf-8-sig'),'원문')
        self.assertEqual((p/'draft_reviewed.txt').read_text(encoding='utf-8-sig'),'수정문')


    def test_legacy_ai_entrypoint_executes_free_command_without_approval(self):
        with contextlib.redirect_stdout(io.StringIO()):
            result=a.ask_ai('/진단','old UI summary')
        self.assertIn('무료 진단 완료',result)
        self.assertTrue((self.root/'topic_audit.json').exists())

class HttpTests(StudioFixture, unittest.TestCase):
    def setUp(self):
        super().setUp()
        self.server=app.ThreadingHTTPServer(('127.0.0.1',0),app.Handler)
        self.thread=threading.Thread(target=self.server.serve_forever,daemon=True);self.thread.start()
        self.addCleanup(self.stop_server)

    def stop_server(self):
        self.server.shutdown();self.server.server_close();self.thread.join(timeout=3)

    def request(self,path,fields=None,headers=None):
        c=http.client.HTTPConnection('127.0.0.1',self.server.server_port,timeout=3)
        try:
            body=urlencode(fields) if fields is not None else None
            c.request('POST' if fields is not None else 'GET',path,body,headers or {})
            r=c.getresponse();return r.status,r.read().decode('utf-8',errors='replace')
        finally:c.close()

    def test_all_pages_render(self):
        self.run_folder()
        for path in ('/','/assistant','/topics','/results','/result?name=sample','/audit','/generate','/log'):
            with self.subTest(path=path):
                status,body=self.request(path);self.assertEqual(status,200);self.assertIn('세차연구소',body)

    def test_http_private_files_and_traversal_denied(self):
        self.run_folder();(self.root/'.env').write_text('dummy only')
        for path in ('/file?kind=result&name=..&file=.env','/file?kind=result&name=sample&file=.env','/file?kind=image&name=sample&file=..'):
            with self.subTest(path=path):self.assertEqual(self.request(path)[0],400)

    def test_normal_download(self):
        self.run_folder()
        status,body=self.request('/file?kind=result&name=sample&file=blog_post.txt')
        self.assertEqual(status,200);self.assertIn('기존 원고',body)

    def test_invalid_host(self):
        self.assertEqual(self.request('/',headers={'Host':'attacker.example'})[0],403)

    def test_bad_csrf(self):
        self.assertEqual(self.request('/audit',{'token':'invalid'})[0],403)

    def test_bad_content_length(self):
        for length in ('bad','-1','10001'):
            with self.subTest(length=length):self.assertIn(self.request('/audit',{}, {'Content-Length':length})[0],(400,413))

    def test_unapproved_chat_never_calls_ai(self):
        with patch.object(a,'ask_ai') as ai:
            self.assertEqual(self.request('/assistant',{'token':app.TOKEN,'question':'분석해줘'})[0],303)
        ai.assert_not_called();self.assertFalse(app.LOCK.locked())

    def test_unapproved_generation_and_retry_never_start(self):
        with patch.object(e,'generate_one') as generate,patch.object(a,'image_retry') as retry:
            self.request('/generate',{'token':app.TOKEN,'count':'1','confirm':'YES'})
            self.request('/retry_images',{'token':app.TOKEN,'run':'sample'})
        generate.assert_not_called();retry.assert_not_called()

    def test_chat_executes_offline_command(self):
        with contextlib.redirect_stdout(io.StringIO()):
            self.assertEqual(self.request('/assistant',{'token':app.TOKEN,'question':'/진단'})[0],303)
        self.assertTrue((self.root/'topic_audit.json').exists());self.assertFalse(app.LOCK.locked())

    def test_busy_blocks_free_command(self):
        app.LOCK.acquire()
        try:self.request('/assistant',{'token':app.TOKEN,'question':'/진단'})
        finally:app.LOCK.release()
        self.assertFalse((self.root/'topic_audit.json').exists())

    def test_health_reports_current_build_and_bound_port(self):
        status,body=self.request('/health')
        self.assertEqual(status,200)
        data=json.loads(body)
        self.assertEqual(data['version'],'QA 2.1')
        self.assertTrue(data['local_commands'])
        self.assertEqual(data['port'],self.server.server_port)

    def test_build_label_is_visible(self):
        status,body=self.request('/assistant')
        self.assertEqual(status,200)
        self.assertIn('검수 개선판 QA 2.1',body)
        self.assertIn('무료 작업 명령',body)

    def test_missing_page_returns_404(self):
        self.assertEqual(self.request('/missing')[0],404)


if __name__=='__main__':unittest.main()
