"""Secha AI Studio, Python stdlib; stdlib web UI (no Streamlit/pyarrow)."""
import html, json, os, secrets, threading, io, contextlib, webbrowser, sys
from datetime import datetime
from http.server import ThreadingHTTPServer, BaseHTTPRequestHandler
from pathlib import Path
from urllib.parse import parse_qs, urlparse, quote
import secha_engine as engine
import assistant_tools

BASE=engine.BASE_DIR
TOKEN=secrets.token_urlsafe(24)
LOCK=threading.Lock()
STATE={'busy':False,'log':'', 'notice':'준비 완료', 'audit':None, 'chat':[], 'last_action':'', 'pending_run':''}

JOURNAL_LOCK=threading.Lock()
def record(action,status):
 # Persist operational outcomes only: no API keys, prompts, manuscript text or raw exceptions.
 try:
  with JOURNAL_LOCK:
   p=BASE/'operation_history.jsonl'
   if p.is_symlink():raise OSError('Invalid journal')
   with p.open('a',encoding='utf-8') as f:
    f.write(json.dumps({'time':datetime.now().isoformat(timespec='seconds'),'action':action,'status':engine.redact_sensitive(status)},ensure_ascii=False)+'\n')
 except OSError:
  STATE['notice']+=' (작업 기록 저장 실패)'

def journal_text():
 p=BASE/'operation_history.jsonl'
 if not p.is_file() or p.is_symlink():return ''
 from collections import deque
 with p.open(encoding='utf-8') as f:return ''.join(deque(f,maxlen=100))

def chat_worker(question,summary):
 try:
  answer=assistant_tools.ask_ai(question,summary,approved=True)
  STATE['chat'].append(('AI 관리자',answer));STATE['notice']='AI 답변 완료'
 except Exception as exc:STATE['notice']='AI 대화 실패: '+type(exc).__name__
 finally:
  record('ai_chat',STATE['notice']);STATE['busy']=False;LOCK.release()

def esc(s): return html.escape(engine.redact_sensitive(s),quote=True)
def remaining():
 h=engine.load_history(); return h,engine.select_topics(h,len(engine.TOPICS),engine.load_existing_titles())
def runs():
 p=BASE/'output'
 return sorted([x for x in p.iterdir() if x.is_dir() and not x.is_symlink()],reverse=True) if p.exists() and not p.is_symlink() else []
def report(p):
 try: return json.loads(assistant_tools.safe_file(BASE,p.name,'review_report.json').read_text(encoding='utf-8-sig'))
 except (OSError,ValueError): return {}
def layout(body):
 body='<small>실행 중인 Python: '+esc(sys.version.split()[0])+'</small>'+body
 return '''<!doctype html><html lang="ko"><meta charset="utf-8"><meta name="viewport" content="width=device-width,initial-scale=1"><title>세차연구소 AI Studio</title><style>
:root{font-family:system-ui,'Malgun Gothic',sans-serif;color:#e6edf5;background:#0d1420}*{box-sizing:border-box}body{max-width:1150px;margin:auto;padding:24px}h1{font-size:27px}nav{display:flex;gap:8px;flex-wrap:wrap;margin:18px 0}nav a,.btn,button{background:#22344d;color:#fff;border:1px solid #456182;border-radius:9px;padding:10px 14px;text-decoration:none;cursor:pointer}button.primary{background:#1971cc}section,.card{background:#172335;border:1px solid #2b405b;border-radius:13px;padding:19px;margin:14px 0}.cards{display:grid;grid-template-columns:repeat(auto-fit,minmax(160px,1fr));gap:12px}.cards .card{margin:0}.number{font-size:30px;font-weight:700}small,.muted{color:#a7b7c9}input,select{background:#0c1828;color:white;border:1px solid #58708c;border-radius:7px;padding:9px}input[type=number]{width:85px}pre{white-space:pre-wrap;overflow-wrap:anywhere;background:#0b1626;padding:15px;border-radius:9px;max-height:500px;overflow:auto}table{border-collapse:collapse;width:100%}td,th{padding:10px;border-bottom:1px solid #34475f;text-align:left}a{color:#8ec8ff}label{display:inline-block;margin:8px} .warning{color:#ffd18b} .ok{color:#9ce5b1} .error{color:#ffb1b1}textarea{width:100%;height:300px;background:#0b1626;color:#fff;border:1px solid #34475f}img{max-width:280px;max-height:200px;object-fit:contain;margin:8px}</style><body><h1>🚗 세차연구소 AI Studio</h1><small>Python 실행 환경 · 로컬 전용 · 네이버 자동 발행 없음</small><nav><a href="/">대시보드</a><a href="/audit">무료 진단</a><a href="/generate">원고 생성</a><a href="/results">결과·검수</a><a href="/topics">주제 관리</a><a href="/assistant">AI 관리자</a></nav>''' +body+'''<p class="muted">검수 통과는 사실 검증이나 발행 승인이 아닙니다. 게시 전 수동 검토하세요.</p></body></html>'''
def postform(action,inner):return f'<form method="post" action="{action}"><input type="hidden" name="token" value="{TOKEN}">{inner}</form>'
def render(path,params):
 hist, rem=remaining(); rr=runs()
 if path=='/':
  cards=''.join(f'<div class="card"><div class="muted">{name}</div><div class="number">{val}</div></div>' for name,val in [('전체 주제',len(engine.TOPICS)),('남은 주제',len(rem)),('성공 이력',len(hist)),('작업 폴더',len(rr))])
  return layout(f'<div class="cards">{cards}</div><section><h2>실행 상태</h2><p>{esc(STATE["notice"])}</p><p>{"🟡 실행 중" if STATE["busy"] else "🟢 대기 중"}</p><p>OpenAI API: {"설정됨" if engine.OPENAI_KEY else "미설정"}</p><a href="/log">실행 로그 보기</a></section>')
 if path=='/audit':
  audit=STATE['audit']
  try:
   if not audit and (BASE/'topic_audit.json').exists():audit=json.loads((BASE/'topic_audit.json').read_text(encoding='utf-8'))
  except (ValueError,OSError):audit=None
  body='<section><h2>무료 주제 진단</h2><p>외부 API를 호출하지 않고 주제 규칙만 점검합니다.</p>'+postform('/audit','<button class="primary">무료 진단 실행</button>')+'</section>'
  if audit:
   flags=[x for x in audit.get('topics',[]) if x.get('flags')]
   body+=f'<section>남은 주제 {audit.get("remaining","?")}개 / 점검 권장 {audit.get("flagged","?")}개<p><a href="/file?kind=audit">진단 JSON 다운로드</a></p>'
   body+='<table><tr><th>주제</th><th>점검 사항</th></tr>'+''.join(f'<tr><td>{esc(x.get("topic"))}</td><td>{esc(", ".join(x.get("flags",[])))}</td></tr>' for x in flags)+'</table></section>'
  return layout(body)
 if path=='/generate':
  preview=''.join(f'<li>{esc(t)} <small>({esc(engine.classify_domain(t))})</small></li>' for t,k in rem[:10])
  body='<section><h2>무료 계획 미리보기</h2><ol>'+preview+'</ol></section>'
  body+='<section><h2>유료 AI 원고 생성</h2><p class="warning">OpenAI API 비용 발생. 원고 작성·검수·수정은 글당 최대 6회, 사진 판독은 최대 30회입니다. 별도 AI 이미지 생성 설정 시 비용이 추가됩니다. 네이버 발행은 수동.</p>'
  body+=postform('/generate','<label>글 개수 <input type="number" name="count" min="1" max="20" value="1" required></label><p><label><input type="checkbox" name="approve" value="yes" required> API 비용 발생과 최종 수동 검토를 확인했습니다.</label></p><label>확인 문구 <input name="confirm" placeholder="YES" autocomplete="off" required></label><button class="primary">유료 생성 시작</button>')
  body+='</section><section><p>'+esc(STATE['notice'])+'</p><p><a href="/log">진행 로그 보기 (새로고침)</a></p></section>'
  return layout(body)
 if path=='/log':return layout('<section><h2>실행 로그</h2><p>'+esc(STATE['notice'])+'</p><pre>'+esc(STATE['log'])+'</pre><h3>작업 기록</h3><pre>'+esc(journal_text())+'</pre><a href="/log">새로고침</a></section>')
 if path=='/assistant':
  recent=runs()[:12]
  rows=''.join(f'<option value="{esc(p.name)}" {"selected" if p.name==STATE["pending_run"] else ""}>{esc(p.name)} · {esc(report(p).get("topic",""))}</option>' for p in recent)
  chat=''.join(f'<div class="card"><strong>{esc(who)}</strong><pre>{esc(msg)}</pre></div>' for who,msg in STATE['chat'][-12:])
  body='<section><h2>AI 관리자 대화</h2><p>무료 작업 명령: /진단, /계획, /원고검수 작업폴더, /사진분석 작업폴더, /사진재검색 작업폴더. 일반 질문은 비용 승인 후 AI가 답변합니다.</p>'
  body+=postform('/assistant','<textarea name="question" style="height:110px" maxlength="1500" placeholder="예: 최근 사진이 왜 실패했어? 개선 방법 알려줘"></textarea><p><label><input type="checkbox" name="approve" value="yes"> 일반 AI 질문의 API 비용을 승인합니다 (무료 명령은 승인 불필요).</label></p><p><button class="primary">명령 실행 / 승인한 AI 질문</button></p>')
  body+='</section><section><h2>작업 명령</h2><p class="warning">사진 재검색은 외부 API 비용과 네트워크 요청이 발생할 수 있습니다. 원고·주제 이력은 변경하지 않습니다.</p>'
  body+=postform('/retry_images','<label>대상 작업 <select name="run">'+rows+'</select></label><p><label><input type="checkbox" name="approve" value="yes" required> 비용 발생 가능성과 원고 수동 확인에 동의</label></p><button>사진 다시 찾기</button>')
  body+='</section><section><h2>대화 및 실행 기록</h2>'+chat+'<p><a href="/log">전체 실행 로그</a></p></section>'
  return layout(body)
 if path=='/topics':
  rows=''.join(f'<tr><td>{esc(t)}</td><td>{esc(engine.classify_domain(t))}</td><td>{esc(engine.topic_safety_tier(t))}</td></tr>' for t,k in rem)
  return layout(f'<section><h2>남은 주제 {len(rem)}개</h2><p>주제 이력은 이 화면에서 삭제하지 않습니다.</p><table><tr><th>주제</th><th>분야</th><th>위험도</th></tr>{rows}</table></section>')
 if path=='/results':
  rows=''.join(f'<tr><td><a href="/result?name={quote(p.name)}">{esc(p.name)}</a></td><td>{esc(report(p).get("status","미확인"))}</td><td>{esc(report(p).get("topic",""))}</td></tr>' for p in rr[:200])
  return layout('<section><h2>작업 결과</h2><table><tr><th>폴더</th><th>검수</th><th>주제</th></tr>'+rows+'</table></section>')
 if path=='/result':
  name=params.get('name',[''])[0]
  try:p=assistant_tools.safe_run(BASE,name)
  except ValueError:return layout('<p>잘못된 작업 폴더</p>')
  rep=report(p); body=f'<section><h2>{esc(name)}</h2><p>검수 상태: {esc(rep.get("status","미확인"))}</p><p class="warning">{esc(" / ".join(map(str,rep.get("issues",[]))))}</p>'
  for filename in ('review_report.json','blog_post.txt'):
   f=assistant_tools.safe_file(BASE,name,filename)
   if f.is_file():
    body+=f'<h3>{esc(filename)} <a href="/file?kind=result&name={quote(name)}&file={filename}">다운로드</a></h3><pre>{esc(f.read_text(encoding="utf-8-sig",errors="replace")[:40000])}</pre>'
  imgdir=p/'images'
  if imgdir.is_dir() and not imgdir.is_symlink():
   for f in sorted(imgdir.iterdir()):
    if f.is_file() and not f.is_symlink() and f.suffix.lower() in ('.png','.jpg','.jpeg','.webp'):
     url=f'/file?kind=image&name={quote(name)}&file={quote(f.name)}'
     body+=f'<div><a href="{url}">{esc(f.name)} 다운로드</a><p><img src="{url}" loading="lazy"></p></div>'
  for f in sorted(p.glob('image_retry_report*.json')):
   if f.is_file() and not f.is_symlink():body+='<h3>'+esc(f.name)+'</h3><pre>'+esc(f.read_text(encoding='utf-8-sig')[:40000])+'</pre>'
  return layout(body+'</section>')
 return layout('<p>페이지를 찾을 수 없습니다.</p>')

def image_worker(name):
 try:
  def logger(line):
   STATE['log'] += engine.redact_sensitive(line)+'\n'
  msg=assistant_tools.image_retry(BASE,name,logger)
  STATE['notice']=msg
  STATE['chat'].append(('시스템',msg))
 except Exception as exc:
  STATE['notice']=f'사진 재검색 실패: {type(exc).__name__}'
  STATE['log']+='사진 재검색 오류: '+type(exc).__name__+'\n'
 finally:
  record('retry_images',STATE['notice'])
  STATE['busy']=False
  LOCK.release()

class LiveLog(io.StringIO):
 def write(self,text):
  result=super().write(engine.redact_sensitive(text))
  STATE['log']=self.getvalue()
  return result

def worker(chosen):
 log=LiveLog(); success=0
 try:
  history=engine.load_history()
  with contextlib.redirect_stdout(log):
   for idx,(t,k) in enumerate(chosen,1):
    print(f'[{idx}/{len(chosen)}] {t}',flush=True)
    try: success+=int(engine.generate_one(t,k,history))
    except Exception as exc: print('원고 생성 실패:',type(exc).__name__)
  STATE['notice']=f'완료: {success}/{len(chosen)}개 정상 처리 (수동 검토 필요)'
 except Exception as exc:STATE['notice']=f'작업 오류: {type(exc).__name__}'
 finally:
  STATE['log']=log.getvalue(); record('generate',STATE['notice']); STATE['busy']=False; LOCK.release()

class Handler(BaseHTTPRequestHandler):
 def send(self,data,status=200,mime='text/html; charset=utf-8',filename=None):
  self.send_response(status);self.send_header('Content-Type',mime);self.send_header('Content-Length',str(len(data)));self.send_header('X-Content-Type-Options','nosniff');self.send_header('Cache-Control','no-store');self.send_header('X-Frame-Options','DENY')
  if filename:self.send_header('Content-Disposition',f'attachment; filename="{filename}"')
  self.end_headers();self.wfile.write(data)
 def do_GET(self):
  if not self.valid_host():return self.send(b'Forbidden host',403,'text/plain')
  u=urlparse(self.path);params=parse_qs(u.query)
  if u.path=='/file':
   kind=params.get('kind',[''])[0];name=params.get('name',[''])[0];filename=params.get('file',[''])[0]
   try:
    if kind=='audit':
     p=BASE/'topic_audit.json'
     if p.is_symlink():raise ValueError('잘못된 경로')
    elif kind in ('result','image'):
     p=assistant_tools.safe_file(BASE,name,filename,image=kind=='image')
    else:raise ValueError('잘못된 종류')
   except ValueError:return self.send(b'Invalid request',400,'text/plain')
   if not p.is_file():return self.send(b'Not found',404,'text/plain')
   mime='image/png' if p.suffix=='.png' else 'image/jpeg' if p.suffix.lower() in ('.jpg','.jpeg') else 'image/webp' if p.suffix.lower()=='.webp' else 'application/octet-stream'
   data=p.read_bytes() if kind=='image' else engine.redact_sensitive(p.read_text(encoding='utf-8-sig',errors='replace')).encode('utf-8')
   return self.send(data,mime=mime,filename=None if kind=='image' else 'download'+p.suffix)
  if u.path not in ('/','/audit','/generate','/log','/assistant','/topics','/results','/result'):return self.send(b'Not found',404,'text/plain')
  try:self.send(render(u.path,params).encode('utf-8'))
  except Exception:self.send(layout('<h2>화면 오류</h2><pre>'+'세부 오류 정보는 노출하지 않습니다.'+'</pre>').encode('utf-8'),500)
 def valid_host(self):
  return self.headers.get('Host') in (f'127.0.0.1:{self.server.server_port}',f'localhost:{self.server.server_port}')
 def do_POST(self):
  if not self.valid_host():return self.send(b'Forbidden host',403,'text/plain')
  try:size=int(self.headers.get('Content-Length','0'))
  except ValueError:return self.send(b'Invalid length',400,'text/plain')
  if size<0:return self.send(b'Invalid length',400,'text/plain')
  if size>10000:return self.send(b'Too large',413,'text/plain')
  fields=parse_qs(self.rfile.read(size).decode('utf-8',errors='replace'))
  if fields.get('token',[''])[0]!=TOKEN:return self.send(b'Forbidden',403,'text/plain')
  path=urlparse(self.path).path
  if path=='/assistant':
   question=fields.get('question',[''])[0].strip()[:1500]
   if not question:STATE['notice']='질문을 입력하세요.'
   elif not LOCK.acquire(blocking=False):STATE['notice']='다른 작업이 실행 중입니다.'
   else:
    try:
     STATE['chat'].append(('사용자',question))
     answer=assistant_tools.local_command(question,BASE)
     if question.startswith('/사진재검색 ') and answer is not None:
      STATE['pending_run']=question.split(maxsplit=1)[1]
     if answer is None:
      if fields.get('approve',[''])[0]!='yes':
       answer='실행 거부: 유료 AI 질문 비용 승인 필요. 무료 작업은 /도움말을 확인하세요.'
      else:
       recent=runs()[:4]
       summary=json.dumps({'remaining_topics':len(remaining()[1]),'last_runs':[
           {k:report(p).get(k) for k in ('topic','status','issues')} for p in recent]},ensure_ascii=False,default=str)
       STATE['busy']=True;STATE['notice']='AI 응답 대기 중'
       threading.Thread(target=chat_worker,args=(question,summary),daemon=True).start()
       answer=None
     if answer is not None:
      STATE['chat'].append(('AI 관리자',answer));STATE['notice']='관리자 명령 처리 완료'
      record('assistant','completed')
      LOCK.release()
    except Exception as exc:
     STATE['notice']='관리자 처리 실패: '+type(exc).__name__;STATE['busy']=False;LOCK.release()
   target='/assistant'
  elif path=='/retry_images':
   name=fields.get('run',[''])[0]
   if fields.get('approve',[''])[0]!='yes':STATE['notice']='비용 승인 필요'
   elif not LOCK.acquire(blocking=False):STATE['notice']='다른 작업이 실행 중입니다.'
   else:
    try:
     assistant_tools.safe_run(BASE,name)
     STATE['busy']=True;STATE['log']='';STATE['notice']='사진 재검색 중'
     threading.Thread(target=image_worker,args=(name,),daemon=True).start()
    except Exception as exc:STATE['notice']='실행 거부: '+type(exc).__name__;STATE['busy']=False;LOCK.release()
   target='/assistant'
  elif path=='/audit':
   if not LOCK.acquire(blocking=False):STATE['notice']='다른 작업이 실행 중입니다.'
   else:
    try:STATE['audit']=engine.offline_topic_audit();STATE['notice']='무료 진단 완료'
    except Exception as exc:STATE['notice']='진단 오류: '+type(exc).__name__
    finally:LOCK.release()
   target='/audit'
  elif path=='/generate':
   try:count=int(fields.get('count',['0'])[0])
   except ValueError:count=0
   if not (1<=count<=20 and fields.get('approve',[''])[0]=='yes' and fields.get('confirm',[''])[0].strip().upper()=='YES' and engine.OPENAI_KEY):
    STATE['notice']='실행 거부: 글 개수, 승인, YES, API 키를 확인하세요.'
   elif not LOCK.acquire(blocking=False):STATE['notice']='이미 생성 중입니다.'
   else:
    try:
     hist, rem=remaining();chosen=rem[:count]
     if not chosen:STATE['notice']='생성할 주제가 없습니다.';LOCK.release()
     else:
      STATE['busy']=True;STATE['log']='';STATE['notice']=f'{len(chosen)}개 생성 시작'
      threading.Thread(target=worker,args=(chosen,),daemon=True).start()
    except Exception as exc:STATE['notice']=f'시작 오류: {type(exc).__name__}';STATE['busy']=False;LOCK.release()
   target='/log'
  else:return self.send(b'Not found',404,'text/plain')
  record(path,STATE['notice'])
  self.send_response(303);self.send_header('Location',target);self.end_headers()
 def log_message(self,*args):pass

if __name__=='__main__':
 os.environ.setdefault('SECHA_BASE_DIR',str(BASE))
 server=ThreadingHTTPServer(('127.0.0.1',8501),Handler)
 print('Secha AI Studio: http://127.0.0.1:8501')
 if os.getenv('SECHA_NO_BROWSER')!='1':webbrowser.open('http://127.0.0.1:8501')
 server.serve_forever()
