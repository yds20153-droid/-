"""세차연구소 반자동 통합판: 단일 원고 + 사진 위치 표시 + 이미지 검증.
.env에 기존 키들과 PIXABAY_API_KEY를 설정하세요. 자동 발행하지 않습니다.
"""
import base64
import hashlib
import hmac
import os
import json
import re
import shutil
import sys
import tempfile
from datetime import datetime, timezone
from pathlib import Path
from urllib.parse import urlencode, urlparse

import requests
from dotenv import load_dotenv
from openai import OpenAI

BASE_DIR = Path(os.getenv("SECHA_BASE_DIR", str(Path(__file__).resolve().parent))).resolve()
load_dotenv(BASE_DIR / ".env")
ACCESS_KEY = os.getenv("COUPANG_ACCESS_KEY")
SECRET_KEY = os.getenv("COUPANG_SECRET_KEY")
OPENAI_KEY = os.getenv("OPENAI_API_KEY")
PIXABAY_KEY = os.getenv("PIXABAY_API_KEY")
ALLOW_PAID_AI_IMAGES = os.getenv("ALLOW_PAID_AI_IMAGES", "0") == "1"
MAX_REVISIONS = 2
ARTICLE_STYLE_GUIDANCE = (
    "원고는 독자에게 차분하게 설명하듯 자연스러운 해요체로 작성하세요. "
    "본문에서는 '~합니다', '~해야 합니다', '~필요합니다' 같은 보고서 말투를 반복하지 말고 "
    "'확인해 주세요', '살펴보면 좋아요', '주의해 주세요'처럼 문맥에 맞게 표현하세요. "
    "짧고 명확한 문장과 자연스러운 문단 연결을 사용하고, 모든 문장을 같은 어미로 끝내지 마세요. "
    "친근함을 위해 반말, 과도한 감탄사, 이모지, 허구의 경험담을 넣지 마세요. "
    "전문 용어와 사실의 정확성은 유지하세요. 안전 지시는 부드럽게 약화하지 마세요. "
    "운행 중단, 시동 정지, 화상 위험, 고온 캡 개방 금지 등은 "
    "'운행하지 마세요', '시동을 꺼 주세요', '뜨거운 캡은 절대 열지 마세요'처럼 "
    "분명하게 쓰고 선택적인 권유로 바꾸지 마세요."
)

def redact_sensitive(value):
    text = str(value)
    for key in (OPENAI_KEY, PIXABAY_KEY, ACCESS_KEY, SECRET_KEY):
        if key:
            text = text.replace(key, '[비밀키 숨김]')
    text = re.sub(r'(?i)((?:api[_-]?key|access[_-]?key|secret[_-]?key|token)\s*[=:]\s*)[^\s&"\']+', r'\1[숨김]', text)
    text = re.sub(r'\bsk-[A-Za-z0-9_-]{8,}', '[비밀키 숨김]', text)
    return text

# 자동차 관리 주제 확장 목록. 실제 생성 성공 시에만 사용 이력에 기록합니다.
TOPICS = [
    ("자동차 타이어 공기압 올바르게 관리하는 방법", "자동차 공기주입기"),
    ("타이어 편마모 원인과 점검 방법", "타이어 공기압 측정기"),
    ("자동차 타이어 교체 시기 확인 방법", "타이어 트레드 측정기"),
    ("여름철 타이어 관리에서 주의할 점", "타이어 공기주입기"),
    ("겨울철 타이어 관리와 안전 운전 요령", "타이어 공기압 측정기"),
    ("자동차 와이퍼 교체 시기와 관리법", "자동차 와이퍼"),
    ("유리 유막의 원인과 제거 시 주의사항", "자동차 유막제거제"),
    ("자동차 발수코팅 관리와 주의사항", "자동차 발수코팅제"),
    ("실내 유리 김서림 원인과 예방 방법", "자동차 유리 세정제"),
    ("자동차 실내 먼지 청소 방법", "차량용 청소기"),
    ("자동차 세차 후 물자국 줄이는 방법", "세차 드라잉타월"),
    ("자동차 세차용 타월 종류와 사용법", "세차 극세사 타월"),
    ("차량용 점프스타터 선택 시 확인할 사항", "차량용 점프스타터"),
    ("자동차 배터리 방전 예방 습관", "차량용 배터리 테스터"),
    ("자동차 에어컨 필터 관리 방법", "자동차 에어컨 필터"),
    ("자동차 실내 냄새 관리 시 주의사항", "자동차 실내 클리너"),
    ("장마철 차량 관리 체크리스트", "자동차 유리 발수코팅제"),
    ("자동차 트렁크 정리와 비상용품 점검", "자동차 트렁크 정리함"),
    ("자동차 전조등 관리와 야간 시야 확보", "자동차 헤드라이트 복원제"),
    ("차량 외장 플라스틱 관리 방법", "자동차 플라스틱 복원제"),
    ('엔진오일 점검 시 확인해야 할 사항', '엔진오일 게이지'),
    ('엔진오일 점도 표기 읽는 방법', '엔진오일'),
    ('엔진오일 경고등 점등 시 대처 방법', '자동차 엔진오일'),
    ('엔진룸 누유 흔적 확인 방법', '자동차 누유 점검'),
    ('엔진룸 먼지 관리 시 주의사항', '엔진룸 청소용품'),
    ('냉각수 부족 징후와 점검 요령', '자동차 냉각수'),
    ('냉각수 색상만으로 상태를 판단하면 안 되는 이유', '자동차 냉각수'),
    ('자동차 과열 경고가 뜰 때 안전하게 대처하는 방법', '자동차 냉각수'),
    ('워터펌프 이상 징후와 점검 포인트', '자동차 냉각수'),
    ('구동벨트 마모를 의심할 수 있는 소리와 증상', '자동차 벨트'),
    ('시동 직후 엔진 소음 점검 체크리스트', '자동차 엔진오일'),
    ('엔진오일 교환 후 확인할 사항', '엔진오일'),
    ('차량별 엔진오일 규격을 확인하는 방법', '엔진오일'),
    ('엔진룸에서 탄 냄새가 날 때 확인할 부분', '자동차 엔진룸 점검'),
    ('브레이크액 점검과 교환 시 주의사항', '자동차 브레이크액'),
    ('브레이크 페달이 평소보다 깊게 들어갈 때', '자동차 브레이크액'),
    ('제동 시 차가 한쪽으로 쏠리는 원인', '자동차 브레이크 패드'),
    ('브레이크 디스크 변형 의심 증상', '자동차 브레이크 디스크'),
    ('브레이크 소음 종류별 점검 포인트', '자동차 브레이크 패드'),
    ('주행 중 하체에서 덜컹거리는 소리의 원인', '자동차 하체 점검'),
    ('과속방지턱 통과 시 소음 점검법', '자동차 서스펜션'),
    ('쇼크업소버 이상 징후 알아보기', '자동차 쇼크업소버'),
    ('로어암 부싱 마모 증상과 점검 방법', '자동차 하체 부싱'),
    ('스태빌라이저 링크 이상 증상', '자동차 스태빌라이저 링크'),
    ('핸들 떨림이 발생할 때 점검 순서', '자동차 휠 밸런스'),
    ('고속 주행 시 차체 진동의 주요 원인', '자동차 휠 밸런스'),
    ('주차 후 바닥에 액체가 떨어졌을 때 구분법', '자동차 누유 점검'),
    ('자동차 하부 부식 예방 관리법', '자동차 언더코팅'),
    ('자동차 퓨즈 역할과 확인 시 주의사항', '자동차 퓨즈'),
    ('퓨즈가 반복해서 끊어질 때 확인할 점', '자동차 퓨즈'),
    ('블랙박스 주차 녹화와 배터리 관리', '블랙박스 보조배터리'),
    ('블랙박스 메모리카드 관리 방법', '블랙박스 메모리카드'),
    ('후미등이 들어오지 않을 때 점검 순서', '자동차 후미등 전구'),
    ('방향지시등 점멸 속도가 빨라졌을 때', '자동차 방향지시등 전구'),
    ('자동차 실내등 관리와 교체 시 주의사항', '자동차 실내등'),
    ('자동차 USB 충전기 선택 시 확인 사항', '차량용 USB 충전기'),
    ('자동차 시거잭 전원 사용 시 주의사항', '차량용 시거잭'),
    ('자동차 경적이 작동하지 않을 때 점검 항목', '자동차 퓨즈'),
    ('계기판 경고등 색깔별 대응 원칙', '자동차 OBD2 스캐너'),
    ('차량 전자장치 초기화가 필요한 상황', '자동차 OBD2 스캐너'),
    ('후방카메라 화면이 흐릴 때 관리 방법', '후방카메라 클리너'),
    ('자동차 문짝 고무 몰딩 관리 방법', '자동차 고무 몰딩 보호제'),
    ('도어 힌지 소음 관리와 윤활 주의사항', '자동차 힌지 윤활제'),
    ('자동차 도어 잠금장치 관리 방법', '자동차 도어 윤활제'),
    ('트렁크 누수 흔적 확인하는 방법', '자동차 방수 테이프'),
    ('자동차 도장면 미세 흠집 관리법', '자동차 컴파운드'),
    ('차량 도장면 새똥 제거 시 주의사항', '자동차 버그 클리너'),
    ('차량 도장면 벌레 자국 제거 방법', '자동차 버그 클리너'),
    ('자동차 외장 크롬 몰딩 관리법', '자동차 크롬 클리너'),
    ('자동차 번호판 주변 오염 관리법', '자동차 세차 브러쉬'),
    ('차량 루프랙 관리와 적재 주의사항', '자동차 루프랙'),
    ('자동차 범퍼 긁힘 관리 시 주의사항', '자동차 컴파운드'),
    ('자동차 문콕 예방을 위한 주차 습관', '자동차 도어가드'),
    ('자동차 선루프 배수구 관리 시 주의사항', '자동차 청소 브러쉬'),
    ('자동차 시트 재질별 관리 방법', '자동차 시트 클리너'),
    ('가죽 시트 관리에서 피해야 할 행동', '자동차 가죽 클리너'),
    ('패브릭 시트 얼룩 관리법', '패브릭 시트 클리너'),
    ('차량 바닥매트 세척과 건조 방법', '자동차 매트 클리너'),
    ('자동차 안전벨트 오염 관리법', '자동차 실내 클리너'),
    ('자동차 핸들 오염 관리와 주의사항', '자동차 실내 클리너'),
    ('차량 컵홀더 틈새 청소 방법', '자동차 틈새 브러쉬'),
    ('자동차 송풍구 먼지 관리법', '자동차 송풍구 브러쉬'),
    ('차량 실내 결로와 습기 줄이는 습관', '차량용 제습제'),
    ('자동차 실내 플라스틱 변색 관리법', '자동차 실내 보호제'),
    ('차량용 방향제 선택 시 확인할 점', '차량용 방향제'),
    ('차량 시트 포지션을 올바르게 조절하는 방법', '자동차 허리 쿠션'),
    ('자동차 헤드레스트 조절 방법', '자동차 목쿠션'),
    ('차량용 휴대전화 거치대 설치 시 주의사항', '차량용 휴대폰 거치대'),
    ('겨울철 자동차 성에 제거 시 주의사항', '자동차 성에 제거기'),
    ('겨울철 도어 손잡이가 얼었을 때 대처법', '자동차 성에 제거제'),
    ('폭염에 주차한 차량 탑승 전 점검사항', '자동차 햇빛가리개'),
    ('여름철 차량 실내 물품 보관 주의사항', '자동차 정리함'),
    ('장거리 운전 전 차량 점검 체크리스트', '자동차 비상용품'),
    ('고속도로 갓길 정차 시 안전 수칙', '자동차 안전삼각대'),
    ('차량용 소화기 선택과 비치 방법', '차량용 소화기'),
    ('자동차 비상탈출 도구 사용 전 알아둘 점', '차량용 비상탈출 망치'),
    ('야간 운전 시 눈부심을 줄이는 운전 습관', '자동차 선바이저'),
    ('안개 낀 날 운전 전 확인할 사항', '자동차 안개등'),
    ('차량 침수 후 시동을 걸면 안 되는 이유', '자동차 비상용품'),
    ('눈길 주행 후 차량 관리 체크리스트', '자동차 하부 세차용품'),
    ('장거리 운전 시 졸음운전 예방 습관', '자동차 목쿠션'),
    ('초보 운전자를 위한 차량 비상용품 목록', '자동차 비상용품'),
    ('장기간 주차할 때 차량 관리 체크리스트', '자동차 차량 커버'),
    ('자동차 연비가 갑자기 나빠졌을 때 점검 항목', '자동차 OBD2 스캐너'),
    ('급가속과 급제동이 연비에 미치는 영향', '자동차 연비 관리'),
    ('공회전 습관과 연료 소비 알아보기', '자동차 연비 관리'),
    ('자동차 연료 주입 시 주의사항', '자동차 주유 깔때기'),
    ('차량에 불필요한 짐을 줄여야 하는 이유', '자동차 트렁크 정리함'),
    ('크루즈컨트롤 사용 시 주의사항', '자동차 운전 보조용품'),
    ('자동차 변속 충격을 느낄 때 점검 사항', '자동차 미션오일'),
    ('자동변속기 오일 점검 시 확인할 것', '자동차 미션오일'),
    ('디젤 차량 DPF 경고등의 의미와 대처법', '디젤 DPF 클리너'),
    ('디젤 차량 요소수 보충 시 주의사항', '자동차 요소수'),
    ('자동차 주행거리별 점검 항목 정리', '자동차 정비 수첩'),
    ('자동차 정기검사 전 확인할 사항', '자동차 OBD2 스캐너'),
    ('폼랜스와 폼건의 차이 알아보기', '자동차 폼건'),
    ('자동차 세차 버킷 관리 방법', '세차 버킷'),
    ('세차용 브러시를 부위별로 구분해야 하는 이유', '자동차 세차 브러쉬'),
    ('차량 틈새 물기 제거하는 방법', '자동차 드라잉 에어건'),
    ('세차용품 보관과 건조 방법', '세차용품 정리함'),
    ('자동차 왁스와 실런트 차이점', '자동차 왁스'),
    ('자동차 퀵디테일러 사용 시 주의사항', '자동차 퀵디테일러'),
    ('자동차 타르 오염 제거 시 주의사항', '자동차 타르 제거제'),
    ('자동차 휠 세정제 선택 시 주의사항', '자동차 휠 클리너'),
    ('세차용 스프레이 용기 라벨 관리 방법', '세차용 스프레이 용기'),
    ('겨울철 세차 시 물이 얼지 않도록 주의할 점', '자동차 세차용품'),
    ('차량 하부 세차가 필요한 상황', '자동차 하부 세차기'),
    ('타이어 옆면 손상 발견 시 대처 방법', '타이어 점검용 손전등'),
    ('타이어 트레드 홈에 낀 돌 제거 시 주의사항', '타이어 홈 청소 도구'),
    ('타이어 수리 가능 여부를 판단할 때 확인할 것', '타이어 펑크 수리 키트'),
    ('타이어 사이즈 표기 읽는 방법', '타이어 공기압 측정기'),
    ('타이어 하중지수와 속도등급의 의미', '타이어 공기압 측정기'),
    ('휠 너트 체결 토크가 중요한 이유', '자동차 토크렌치'),
    ('스페어타이어 점검과 보관 방법', '자동차 공기압 측정기'),
    ('타이어 밸브캡 관리와 분실 시 주의사항', '타이어 밸브캡'),
    ('휠 림 손상 발견 시 점검 방법', '자동차 휠 클리너'),
    ('타이어 소음이 커졌을 때 확인할 사항', '타이어 트레드 측정기'),
    ('타이어 공기압 측정기를 올바르게 사용하는 방법', '타이어 공기압 측정기'),
    ('타이어 펑크 의심 시 안전하게 정차하는 방법', '타이어 펑크 수리 키트'),
]
HISTORY_PATH = BASE_DIR / "topic_history.json"
# 같은 세부 주제를 반복하지 않도록 그룹별 1개씩 우선 선택합니다.
TOPIC_GROUPS = [
    "타이어 공기압", "타이어 편마모", "타이어 교체", "여름철 타이어", "겨울철 타이어",
    "와이퍼", "유막", "발수코팅", "김서림", "실내 먼지", "세차 물자국",
    "세차 타월", "점프스타터", "배터리 방전", "에어컨 필터", "실내 냄새",
    "장마철", "트렁크", "전조등", "외장 플라스틱",
]



# 기존 네이버 블로그 게시물 제목 (PDF 2개에서 확인된 37개).
# 나머지 7개는 확인 후 existing_blog_titles.txt에 한 줄씩 추가하세요.
EXISTING_TITLES_PATH = BASE_DIR / "existing_blog_titles.txt"

# 제목이 달라도 핵심 소재가 같으면 보수적으로 제외합니다.
# 너무 광범위한 "자동차", "관리" 같은 단어는 쓰지 않습니다.
SUBJECT_RULES = [
    ("타이어 공기압", ("공기압", "tpms", "공기주입기", "여름철 타이어", "겨울철 타이어")),
    ("타이어 편마모", ("편마모",)),
    ("타이어 교체", ("타이어 교체", "타이어 제조일자")),
    ("와이퍼", ("와이퍼",)),
    ("유막", ("유막",)),
    ("발수코팅", ("발수코팅",)),
    ("유리 관리", ("앞유리", "유리세정제", "유리 세정제", "유리 김서림")),
    ("세차 물자국", ("물자국", "물 얼룩", "워터스팟", "드라잉타월")),
    ("세차 타월", ("타월", "워시미트")),
    ("점프스타터", ("점프스타터",)),
    ("배터리", ("배터리",)),
    ("에어컨 필터", ("에어컨 필터",)),
    ("실내 냄새", ("에어컨 냄새", "실내 냄새", "악취 제거", "에어컨에서 냄새")),
    ("실내 청소", ("실내 먼지", "실내 청소", "무선청소기")),
    ("장마철", ("장마철", "침수 예방", "침수 예방법")),
    ("세차 기초", ("셀프 세차", "손세차", "자동세차", "카샴푸")),
]


def normalize_title(value):
    return re.sub(r"[^가-힣a-z0-9]", "", value.lower())


def subject_labels(value):
    normalized = normalize_title(value)
    return {label for label, terms in SUBJECT_RULES
            if any(normalize_title(term) in normalized for term in terms)}


def load_existing_titles():
    if not EXISTING_TITLES_PATH.exists():
        print("기존 게시물 제목 파일 없음: existing_blog_titles.txt (기존 글 중복 검사 불가)")
        return []
    return [line.strip() for line in EXISTING_TITLES_PATH.read_text(encoding="utf-8-sig").splitlines()
            if line.strip() and not line.lstrip().startswith("#")]


def existing_conflict(topic, titles):
    target = normalize_title(topic)
    labels = subject_labels(topic)
    for old in titles:
        old_normalized = normalize_title(old)
        if target == old_normalized or (labels and labels & subject_labels(old)):
            return old
    return None

def topic_family(topic):
    if "타이어" in topic or "휠 " in topic:
        return "타이어"
    if "세차" in topic or "유막" in topic or "발수" in topic:
        return "세차/유리"
    if "배터리" in topic or "점프스타터" in topic:
        return "전기"
    if "실내" in topic or "에어컨" in topic or "시트" in topic:
        return "실내"
    if any(x in topic for x in ("브레이크", "하체", "서스펜션", "쇼크업소버")):
        return "제동/하체"
    if any(x in topic for x in ("엔진", "냉각수", "워터펌프")):
        return "엔진"
    if any(x in topic for x in ("전조등", "후미등", "퓨즈", "블랙박스")):
        return "전기"
    return "기타"


def attempted_topic_statuses():
    """Read existing outcomes without modifying manuscripts or success history."""
    output = BASE_DIR/'output'
    if not output.exists():
        return {}
    if output.is_symlink():
        raise ValueError('허용하지 않은 작업 이력 경로')
    statuses = {}
    for folder in output.iterdir():
        if not folder.is_dir() or folder.is_symlink():
            continue
        report = folder/'review_report.json'
        if not report.exists():
            continue
        if report.is_symlink():
            raise ValueError('허용하지 않은 검수 보고서 경로')
        try:
            data = json.loads(report.read_text(encoding='utf-8-sig'))
            if not isinstance(data, dict):
                raise ValueError('report object required')
            topic = data.get('topic')
            status = data.get('status', 'UNKNOWN')
            if not isinstance(topic, str) or not topic.strip() or not isinstance(status, str):
                raise ValueError('topic/status required')
        except (OSError, ValueError) as exc:
            raise ValueError('검수 보고서를 읽을 수 없어 중복 방지를 위해 생성을 중단합니다: '+folder.name) from None
        statuses.setdefault(topic, set()).add(status)
    return statuses


def select_topics(history, count, existing_titles=None, *, include_failed=False):
    # 같은 제목은 영구 제외, 같은 계열은 한 실행에서 최대한 분산.
    norm = lambda t: re.sub(r"\s+", "", t).lower()
    used = {norm(t) for t in history}
    for topic, statuses in attempted_topic_statuses().items():
        # Completed or unknown outcomes always remain excluded. Failed-only outcomes
        # can be retried only through the explicit user option.
        if not include_failed or not statuses.issubset({'HOLD', 'ERROR'}):
            used.add(norm(topic))
    existing_titles = existing_titles or []
    pool = [(t, k) for t, k in TOPICS if norm(t) not in used
            and existing_conflict(t, existing_titles) is None]
    selected = []
    families = set()
    while pool and len(selected) < count:
        index = next((i for i, (t, _) in enumerate(pool) if topic_family(t) not in families), 0)
        item = pool.pop(index)
        selected.append(item)
        families.add(topic_family(item[0]))
    return selected



def load_history():
    if not HISTORY_PATH.exists():
        return []
    data = json.loads(HISTORY_PATH.read_text(encoding="utf-8-sig"))
    if not isinstance(data, list) or not all(isinstance(x, str) for x in data):
        raise ValueError("topic_history.json 형식이 잘못되었습니다.")
    return data


def save_history(history):
    if not isinstance(history, list) or not all(isinstance(x, str) for x in history):
        raise ValueError("작성 이력 형식 오류")
    HISTORY_PATH.parent.mkdir(parents=True, exist_ok=True)
    # Refuse simultaneous writes; a crashed writer's lock requires manual inspection.
    lock_path = HISTORY_PATH.with_suffix('.write.lock')
    with lock_path.open('x', encoding='utf-8') as lock:
        lock.write(str(os.getpid()))
    temp = None
    try:
        history = list(dict.fromkeys(load_history() + history))
        with tempfile.NamedTemporaryFile(mode='w', encoding='utf-8', dir=HISTORY_PATH.parent,
                                         prefix='topic_history_', suffix='.tmp', delete=False) as f:
            temp = Path(f.name)
            json.dump(history, f, ensure_ascii=False, indent=2)
            f.flush()
            os.fsync(f.fileno())
        temp.replace(HISTORY_PATH)
    finally:
        if temp is not None:
            temp.unlink(missing_ok=True)
        lock_path.unlink(missing_ok=True)


# 이미지 검색어는 주제의 핵심 부품/상황을 우선합니다.
# 적절한 사진이 없으면 이미지 생성 또는 검토 보류로 넘어갑니다.
IMAGE_SUBJECTS = [
    (("누유", "오일 누출", "오일 새는"), "engine oil leak under car engine bay", "visible real oil leakage or oily residue around a passenger car engine or underside, with no unsafe repair activity", {"oil", "leak", "engine", "car", "motor"}),
    (("엔진오일 경고등", "오일 압력 경고", "유압 경고등"), "red oil pressure warning light car dashboard", "a real passenger-car dashboard showing a genuine red engine oil pressure warning symbol", {"oil", "warning", "dashboard", "car", "engine"}),
    (("과열 경고", "엔진 과열", "수온 경고", "냉각수 온도 경고"), "engine temperature warning light dashboard car", "a real passenger-car dashboard with an engine temperature warning indicator", {"temperature", "warning", "dashboard", "car", "engine"}),
    (("외장 플라스틱", "플라스틱 복원", "플라스틱 트림"), "car exterior plastic trim restoration", "black exterior plastic trim on a passenger car bumper or wheel arch", {"plastic", "trim", "bumper", "car"}),
    (("타이어", "편마모", "휠 "), "car tire tread wheel", "passenger car tire and wheel", {"tire", "tyre", "wheel"}),
    # 구체적인 엔진오일 주제를 일반 엔진오일 주제보다 먼저 검사합니다.
    (("엔진오일 점도", "오일 점도", "점도 표기", "SAE", "0W-20", "5W-30"), "engine oil viscosity SAE 5W30 bottle label", "engine oil container with a clearly visible SAE viscosity grade such as 5W-30", {"oil", "engine", "motor", "lubricant", "viscosity"}),
    (("엔진오일 점검", "엔진오일 양", "오일량", "오일 게이지", "딥스틱"), "car engine oil dipstick", "engine oil dipstick being checked in a passenger car engine bay", {"engine", "oil", "dipstick"}),
    (("엔진오일 교체", "오일 교환", "엔진오일 교환"), "car engine oil change", "engine oil being changed during professional car maintenance", {"engine", "oil", "change", "maintenance"}),
    (("엔진오일",), "automotive engine oil bottle", "automotive engine oil container next to a passenger car", {"engine", "oil", "motor"}),
    (("냉각수", "워터펌프", "과열"), "car engine coolant reservoir", "car engine coolant expansion tank", {"coolant", "engine", "radiator", "reservoir"}),
    (("브레이크액",), "car brake fluid reservoir", "brake fluid reservoir in passenger car", {"brake", "fluid", "reservoir"}),
    (("브레이크",), "car brake disc caliper", "passenger car brake disc and caliper", {"brake", "disc", "caliper", "rotor"}),
    (("전조등", "헤드라이트"), "car headlight close up", "passenger car headlight assembly", {"headlight", "headlamp", "car"}),
    (("후미등", "방향지시등"), "car taillight rear lamp", "passenger car rear light assembly", {"taillight", "tail", "car"}),
    (("실내등",), "car interior dome light", "passenger car interior ceiling dome light", {"interior", "light", "car"}),
    (("퓨즈",), "car fuse box", "passenger car fuse box with fuses", {"fuse", "fuses", "car"}),
    (("배터리", "점프스타터"), "car battery engine bay", "passenger car 12V battery", {"battery", "car", "automotive"}),
    (("와이퍼",), "car windshield wiper", "passenger car windshield wiper blade", {"wiper", "windshield", "car"}),
    (("유막", "앞유리", "발수", "김서림"), "car windshield glass", "passenger car windshield glass", {"windshield", "glass", "car"}),
    (("트렁크",), "car trunk storage", "open passenger car trunk with organized safety supplies", {"trunk", "boot", "car"}),
    (("실내", "시트", "에어컨"), "car interior dashboard", "passenger car interior dashboard", {"interior", "dashboard", "car"}),
    (("세차", "도장면", "광택", "물자국", "컴파운드"), "car detailing cleaning", "clean passenger car body panel during detailing", {"car", "detailing", "wash", "cleaning"}),
    (("하체", "서스펜션", "쇼크업소버", "로어암", "부싱", "스태빌라이저"), "car suspension wheel", "passenger car suspension and wheel assembly", {"suspension", "wheel", "car"}),
    (("엔진", "누유", "벨트", "시동"), "car engine bay", "passenger car engine compartment", {"engine", "car", "motor"}),
]


def is_urgent_warning_topic(topic):
    return any(x in topic for x in ("엔진오일 경고등", "오일 압력 경고", "과열 경고", "엔진 과열", "수온 경고"))


def is_no_affiliate_topic(topic):
    override = TOPIC_OVERRIDES.get(topic)
    if override and override["affiliate"].startswith("추천 없음"):
        return True
    # 긴급 대처 안내에 제품 구매를 섞으면 정차/점검보다 보충을 유도할 수 있음.
    return is_urgent_warning_topic(topic) or any(x in topic for x in (
        "브레이크 페달이", "제동 시 차가", "타이어 펑크 의심", "차량 침수 후", "누유", "오일 누출"))


def product_keyword_for_topic(topic, keyword):
    override = TOPIC_OVERRIDES.get(topic)
    if override:
        return override["affiliate"]
    return "추천 없음 (안전 안내 우선)" if is_no_affiliate_topic(topic) else keyword


def make_image_jobs(topic, keyword=None):
    override = TOPIC_OVERRIDES.get(topic)
    match = next((item for item in IMAGE_SUBJECTS if any(k in topic for k in item[0])), None)
    if match:
        _, query, subject, tags = match
    else:
        # 알맞은 부품 매핑이 없으면 일반 차량 사진만 허용하는 대신,
        # 실제 글 내용에 관련되는지 엄격히 검사합니다.
        query, subject, tags = "passenger car exterior", "a passenger car relevant to the article", {"car", "vehicle", "automobile"}
    if override:
        query = override["image_query"]
        subject = "the actual automotive component or condition described by the search query: " + query
        tags = {w.lower() for w in query.split() if len(w) > 3} | {"car"}
    criteria = (
        f"The article is about: {topic}. The image MUST clearly depict {subject}, "
        "not merely any car or vaguely related equipment. "
        "No wrong connections, invented dashboard warnings, fake labels or unsafe repairs. "
    )
    return [
        {"name": "01_cover", "topic": topic, "placement": "제목 아래 대표 이미지",
         "queries": [query], "tag_groups": [tags],
         "visual_subject": subject, "criteria": criteria,
         "prompt": f"Photorealistic automotive editorial photo of {subject}. "
                   "Realistic mechanical details. No people performing repairs, no text, no logo, no watermark."},
        {"name": "02_article", "topic": topic, "placement": "본문 설명용 이미지",
         "queries": [query], "tag_groups": [tags],
         "visual_subject": subject, "criteria": criteria,
         "prompt": f"Photorealistic automotive detail photo showing {subject}. "
                   "Accurate real-world parts and geometry. No tools attached, no invented labels or numbers, no text."},
    ]


API_PATH = "/v2/providers/affiliate_open_api/apis/openapi/products/search"
IMAGE_MODEL = "gpt-image-1-mini"
VISION_MODEL = "gpt-4.1-mini"
MAX_VISION_CHECKS_PER_JOB = 5  # 이미지 판독 API 비용 상한을 위한 개수 제한


def search_products(keyword):
    query = urlencode({"keyword": keyword, "limit": 5})
    date = datetime.now(timezone.utc).strftime("%y%m%dT%H%M%SZ")
    message = date + "GET" + API_PATH + query
    signature = hmac.new(SECRET_KEY.encode(), message.encode(), hashlib.sha256).hexdigest()
    authorization = (
        f"CEA algorithm=HmacSHA256, access-key={ACCESS_KEY}, "
        f"signed-date={date}, signature={signature}"
    )
    url = "https://api-gateway.coupang.com" + API_PATH + "?" + query
    response = requests.get(url, headers={"Authorization": authorization}, timeout=20)
    response.raise_for_status()
    payload = response.json()
    if str(payload.get("rCode")) != "0":
        raise RuntimeError("쿠팡 API 오류: " + str(payload.get("rMessage", "알 수 없는 오류")))
    data = payload.get("data") or {}
    return [p for p in (data.get("productData") or []) if p.get("productName") and p.get("productUrl")]


def save_product_image(product, folder):
    image_url = product.get("productImage")
    if not image_url or urlparse(image_url).scheme != "https":
        print("쿠팡 상품 이미지 주소가 없거나 HTTPS가 아닙니다.")
        return None
    response = requests.get(image_url, timeout=25)
    response.raise_for_status()
    content_type = response.headers.get("Content-Type", "").split(";")[0].lower()
    extensions = {"image/jpeg": ".jpg", "image/png": ".png", "image/webp": ".webp"}
    if content_type not in extensions:
        print("지원하지 않는 상품 이미지 형식:", content_type)
        return None
    path = folder / ("coupang_product" + extensions[content_type])
    path.write_bytes(response.content)
    print("쿠팡 상품 이미지 저장 완료:", path.name)
    return path


def generate_ai_image(client, prompt, filepath):
    result = client.images.generate(model=IMAGE_MODEL, prompt=prompt, size="1536x1024", n=1, quality="low")
    image_data = result.data[0].b64_json
    if not image_data:
        raise RuntimeError("AI 이미지 데이터가 비어 있습니다.")
    filepath.write_bytes(base64.b64decode(image_data))
    print("AI 이미지 저장 완료:", filepath.name)


def search_pixabay(query):
    if not PIXABAY_KEY:
        print("Pixabay 키 미설정: 검색 생략")
        return []
    response = requests.get(
        "https://pixabay.com/api/",
        params={"key": PIXABAY_KEY, "q": query, "image_type": "photo", "orientation": "horizontal",
                "safesearch": "true", "per_page": 20},
        timeout=25,
    )
    response.raise_for_status()
    return response.json().get("hits", [])


def photo_matches_job(photo, job):
    """Pixabay 태그 기반 보수적 필터. 이미지 내용 자체를 판독하지는 못함."""
    tags = str(photo.get("tags", "")).lower()
    words = {word.strip() for word in tags.replace("-", " ").replace(",", " ").split()}
    # 혈압 측정, 의료 장비, 인물 사진 등 명백히 무관한 후보 배제
    blocked = {"blood", "medical", "medicine", "doctor", "hospital", "patient",
               "arm", "cuff", "sphygmomanometer", "healthcare", "nurse"}
    if words & blocked:
        return False
    # 각 그룹에서 최소 한 단어씩 포함해야 채택
    for group in job["tag_groups"]:
        if not words.intersection(group):
            return False
    return True


def image_mime(image_bytes):
    if image_bytes.startswith(b"\x89PNG\r\n\x1a\n"):
        return "image/png"
    elif image_bytes.startswith(b"\xff\xd8\xff"):
        return "image/jpeg"
    elif image_bytes.startswith(b"RIFF") and image_bytes[8:12] == b"WEBP":
        return "image/webp"
    return None


def verify_photo_with_vision(client, image_bytes, job):
    """실제 픽셀을 분석해 ACCEPT/REJECT 판정. 실패/애매함은 불합격."""
    mime = image_mime(image_bytes)
    if not mime:
        return False
    encoded = base64.b64encode(image_bytes).decode("ascii")
    criteria = (
        f"This photo will illustrate a Korean car-care blog article titled '{job.get('topic', '')}'. "
        f"It will be used as: {job['placement']}. "
        "Accept ONLY if a real passenger car or the relevant real car part is clearly visible, "
        "the image is genuinely relevant to the article, and there are no unsafe, "
        "mechanically implausible, or incorrect maintenance actions. "
        "Reject medical devices, industrial pipes, unrelated equipment, illustrations, "
        "and images where the relevant car part is not visible. "
        + job.get("criteria", "")
        + ("For this tire article, a passenger-car tire and wheel must be clearly visible. "
           if "타이어" in job.get("topic", "") else "")
    )
    result = client.responses.create(
        model=VISION_MODEL,
        instructions=(
            "You are a strict automotive photo checker. Examine the IMAGE, not its tags. "
            "Only respond with the single word ACCEPT or REJECT. "
            "If uncertain, respond REJECT. No explanation."
        ),
        input=[{"role": "user", "content": [
            {"type": "input_text", "text": criteria},
            {"type": "input_image", "image_url": f"data:{mime};base64," + encoded, "detail": "low"},
        ]}],
        max_output_tokens=16,
    )
    return result.output_text.strip().upper() == "ACCEPT"


def save_pixabay_image(client, job, folder, used_ids):
    """태그 1차 + 이미지 실제 내용 AI 2차 검증 후 저장."""
    checked = 0
    for query in job["queries"]:
        print("Pixabay 검색:", query)
        try:
            candidates = search_pixabay(query)
        except requests.RequestException as exc:
            print("Pixabay 검색 실패:", type(exc).__name__)
            continue
        print("Pixabay 검색 후보 수:", len(candidates))
        for photo in candidates:
            photo_id = photo.get("id")
            if not photo_id or f"Pixabay:{photo_id}" in used_ids or not photo_matches_job(photo, job):
                continue
            if checked >= MAX_VISION_CHECKS_PER_JOB:
                print("이미지 분석 횟수 제한 도달:", job["name"])
                return None
            # Pixabay 미리보기로 저비용 판독, 통과한 경우에만 고화질 저장.
            preview_url = photo.get("webformatURL")
            full_url = photo.get("largeImageURL") or preview_url
            if not preview_url or not full_url or any(
                urlparse(u).scheme != "https" for u in (preview_url, full_url)
            ):
                continue
            try:
                preview = requests.get(preview_url, timeout=25)
                preview.raise_for_status()
                if preview.headers.get("Content-Type", "").split(";")[0].lower() not in ("image/jpeg", "image/png", "image/webp") or len(preview.content) > 8_000_000:
                    continue
                checked += 1
                used_ids.add(f"Pixabay:{photo_id}")
                try:
                    accepted = verify_photo_with_vision(client, preview.content, job)
                except Exception as exc:
                    print("이미지 분석 실패, 후보 제외:", type(exc).__name__)
                    accepted = False
                print("이미지 내용 검증:", photo_id, "적합" if accepted else "부적합")
                if not accepted:
                    continue
                response = requests.get(full_url, timeout=25)
                response.raise_for_status()
                content_type = response.headers.get("Content-Type", "").split(";")[0].lower()
                extension = {"image/jpeg": ".jpg", "image/png": ".png", "image/webp": ".webp"}.get(content_type)
                if not extension or len(response.content) > 15_000_000 or image_mime(response.content) != content_type:
                    continue
                filepath = folder / (job["name"] + extension)
                with filepath.open('xb') as f:
                    f.write(response.content)
                used_ids.add(f"Pixabay:{photo_id}")
                print("Pixabay 검증 사진 저장 완료:", filepath.name)
                return {"filename": filepath.name, "source": "Pixabay", "url": photo.get("pageURL", ""),
                        "tags": str(photo.get("tags", "")), "photographer": photo.get("user", ""),
                        "asset_id": f"Pixabay:{photo_id}", "asset_url": full_url}
            except (requests.RequestException, OSError) as exc:
                print("Pixabay 이미지 처리 실패:", type(exc).__name__)
                continue
    return None



# 무료 공개 사진 소스: 상업적 사용 가능한 CC0/PDM/CC BY만 후보로 채택.
# Openverse는 Wikimedia Commons를 색인하기도 하므로 원본 URL 중복을 막습니다.
def search_openverse(query):
    response = requests.get(
        "https://api.openverse.org/v1/images/",
        params={"q": query, "page_size": 20, "category": "photograph", "license": "cc0,pdm,by"},
        headers={"User-Agent": "SechaAutoBlog/1.0 (automotive editorial image search)"},
        timeout=20,
    )
    response.raise_for_status()
    return [{"url": x.get("url"), "preview": x.get("thumbnail") or x.get("url"),
             "page": x.get("foreign_landing_url"), "creator": x.get("creator") or "미상",
             "license": x.get("license"), "license_url": x.get("license_url") or "",
             "title": x.get("title") or "", "source": "Openverse"}
            for x in response.json().get("results", [])
            if str(x.get("license", "")).lower() in ("cc0", "pdm", "by")]


def search_wikimedia(query):
    response = requests.get(
        "https://commons.wikimedia.org/w/api.php",
        params={"action": "query", "generator": "search", "gsrsearch": "filetype:bitmap " + query,
                "gsrnamespace": 6, "gsrlimit": 20, "prop": "imageinfo",
                "iiprop": "url|extmetadata", "iiurlwidth": 800, "format": "json", "formatversion": 2},
        headers={"User-Agent": "SechaAutoBlog/1.0 (automotive editorial image search)"},
        timeout=20,
    )
    response.raise_for_status()
    results = []
    for page in response.json().get("query", {}).get("pages", []):
        info = (page.get("imageinfo") or [{}])[0]
        meta = info.get("extmetadata") or {}
        license_name = str(meta.get("LicenseShortName", {}).get("value", "")).lower()
        # NC, ND, SA 등 추가 조건이 있는 라이선스는 자동 제외.
        if not (license_name in ("cc0", "public domain", "pd", "cc by 4.0", "cc by 3.0", "cc by 2.0", "cc-by-4.0", "cc-by-3.0", "cc-by-2.0")):
            continue
        url = info.get("url")
        if not url or not url.lower().split("?")[0].endswith((".jpg", ".jpeg", ".png", ".webp")):
            continue
        results.append({"url": url, "preview": info.get("thumburl") or url,
                        "page": info.get("descriptionurl"), "creator": "원본 페이지 확인",
                        "license": license_name, "license_url": "원본 페이지 확인",
                        "title": page.get("title", ""), "source": "Wikimedia Commons"})
    return results


def save_open_photo(client, job, folder, used_ids, provider):
    search = search_openverse if provider == "Openverse" else search_wikimedia
    checked = 0
    for query in job["queries"]:
        print(provider + " 검색:", query)
        try:
            candidates = search(query)
        except Exception as exc:
            print(provider + " 검색 실패:", type(exc).__name__)
            continue
        print(provider + " 검색 후보 수:", len(candidates))
        for item in candidates:
            url = item.get("url")
            preview = item.get("preview")
            if not url or not preview or url in used_ids:
                continue
            if any(urlparse(u).scheme != "https" for u in (url, preview)):
                continue
            if checked >= MAX_VISION_CHECKS_PER_JOB:
                return None
            try:
                r = requests.get(preview, timeout=20, headers={"User-Agent": "SechaAutoBlog/1.0"})
                r.raise_for_status()
                ct = r.headers.get("Content-Type", "").split(";")[0].lower()
                if ct not in ("image/jpeg", "image/png", "image/webp") or len(r.content) > 8_000_000:
                    continue
                checked += 1
                used_ids.add(url)
                if not verify_photo_with_vision(client, r.content, job):
                    continue
                full = requests.get(url, timeout=30, headers={"User-Agent": "SechaAutoBlog/1.0"})
                full.raise_for_status()
                content_type = full.headers.get("Content-Type", "").split(";")[0].lower()
                extension = {"image/jpeg": ".jpg", "image/png": ".png", "image/webp": ".webp"}.get(content_type)
                if not extension or len(full.content) > 15_000_000 or image_mime(full.content) != content_type:
                    continue
                filepath = folder / (job["name"] + extension)
                with filepath.open('xb') as f:
                    f.write(full.content)
                used_ids.add(url)
                return {"filename": filepath.name, "source": provider,
                        "url": item.get("page") or url, "photographer": item["creator"],
                        "license": item["license"], "license_url": item["license_url"],
                        "tags": item.get("title", ""), "asset_url": url}
            except Exception as exc:
                print(provider + " 후보 제외:", type(exc).__name__)
    return None


def check_ai_generated_image(client, path, job):
    """생성 이미지의 실제 픽셀을 검토. 불확실하거나 API 오류면 발행 후보에서 제외."""
    return verify_photo_with_vision(client, path.read_bytes(), job)


def quarantine_image(path):
    review_dir = path.parent.parent / "needs_review"
    review_dir.mkdir(exist_ok=True)
    target = review_dir / path.name
    shutil.move(str(path), str(target))
    return target



def make_clean_title(topic):
    """Search-oriented title without fabricated promises or repetitive suffixes."""
    curated = {
        "엔진오일 점검 시 확인해야 할 사항": "엔진오일 양 확인하는 법｜오일 게이지 보는 방법과 주의사항",
        "엔진오일 점도 표기 읽는 방법": "엔진오일 0W-20·5W-30·5W-40 차이｜점도 표기 읽는 법",
        "자동차 과열 경고가 뜰 때 안전하게 대처하는 방법": "자동차 엔진 과열 경고등이 켜졌다면? 안전한 대처 순서",
        "엔진오일 경고등 점등 시 대처 방법": "빨간 엔진오일 압력 경고등이 켜졌다면? 안전한 정차와 대처법",
        "자동차 전조등 관리와 야간 시야 확보": "자동차 전조등이 어두운 이유와 헤드라이트 관리법",
        "차량 외장 플라스틱 관리 방법": "자동차 외장 플라스틱 백화현상 원인과 관리법",
        "타이어 편마모 원인과 점검 방법": "타이어 한쪽만 닳는 이유｜편마모 원인과 점검 방법",
        "자동차 타이어 공기압 올바르게 관리하는 방법": "자동차 타이어 공기압 확인 방법과 적정 공기압 기준",
    }
    if topic in curated:
        return curated[topic]
    t = re.sub(r"\s+", " ", topic).strip().rstrip(". !?")
    t = t.replace("확인해야 할 사항", "확인할 점").replace("에서 주의할 점", "주의사항")
    t = t.replace("올바르게 관리하는 방법", "관리 방법")
    return t[:55]


def clean_blog_body(raw):
    """Remove markdown without damaging ordinary Korean punctuation."""
    out = []
    for original in raw.splitlines():
        line = original.strip()
        if re.fullmatch(r"[-*_ ]{3,}", line):
            out.append("")
            continue
        line = re.sub(r"^#{1,6}\s+", "", line)
        line = re.sub(r"\*\*(.*?)\*\*", r"\1", line)
        line = re.sub(r"^[-*]\s+", "• ", line)
        if line.startswith("|") and line.endswith("|"):
            cells = [c.strip() for c in line.strip("|").split("|")]
            if all(re.fullmatch(r":?-{3,}:?", c) for c in cells):
                continue
            line = " / ".join(cells)
        out.append(line)
    return re.sub(r"\n{3,}", "\n\n", "\n".join(out)).strip()


def remove_repeated_heading(article, title, topic):
    lines = article.splitlines()
    while lines and not lines[0].strip():
        lines.pop(0)
    if lines:
        first = re.sub(r"^#{1,6}\s*", "", lines[0]).strip()
        if first in (title, topic) or first.startswith("제목:"):
            lines.pop(0)
    return "\n".join(lines).strip()


def format_price(value):
    try:
        amount = float(value)
        if not (0 < amount < 1_000_000_000) or not amount.is_integer():
            return None
        return f"{int(amount):,}원"
    except (ValueError, TypeError, OverflowError):
        return None


# A weakly related part is worse than no affiliate product at all.
# Never automatically recommend fitment-specific mechanical replacement parts.
RESTRICTED_PART_TERMS = (
    "게이지", "딥스틱", "센서", "퓨즈", "브레이크 패드", "디스크", "쇼크업소버",
    "로어암", "워터펌프", "전구", "와이퍼", "필터", "냉각수", "엔진오일",
    "벨트", "스태빌라이저", "배터리", "타이어", "루프랙", "휠", "블랙박스",
)
SAFE_KEYWORD_HINTS = (
    "클리너", "세정제", "타월", "브러쉬", "청소기", "복원제", "제습제", "정리함",
    "공기주입기", "공기압 측정기", "트레드 측정기", "발수코팅제", "컴파운드",
    "보호제", "점프스타터", "유막제거제", "테스터", "윤활제", "도어가드",
)


# 호환성·안전성 때문에 부품을 제외한 경우, 안전한 관리 보조용품만 재검색합니다.
# 추천 제품이 없다면 광고 없이 정보성 글로 남깁니다.
SAFE_ALTERNATIVE_KEYWORDS = {
    "엔진오일": "자동차 오일 깔때기",
    "와이퍼": "자동차 유리 세정제",
    "배터리": "자동차 배터리 단자 청소 브러쉬",
    "필터": "자동차 실내 청소 타월",
    "타이어": "타이어 공기압 측정기",
}


def product_search_with_safe_fallback(keyword):
    products = search_products(keyword)
    print(f"1차 쿠팡 검색 결과: {len(products)}개")
    chosen = choose_product(products, keyword)
    if chosen:
        return chosen
    for word, alternate in SAFE_ALTERNATIVE_KEYWORDS.items():
        if word in keyword and alternate != keyword:
            print(f"차종 호환성 우려로 대체 관리용품 검색: {alternate}")
            alternatives = search_products(alternate)
            print(f"대체 상품 검색 결과: {len(alternatives)}개")
            chosen = choose_product(alternatives, alternate)
            if chosen:
                return chosen
            break
    return None


def safety_semantic_checks(topic, article):
    """보수적인 문장 검사. 통과하더라도 사실 정확성을 보증하지 않습니다."""
    issues = []
    if "엔진오일 경고등" in topic:
        # 중요한 안전 문구는 존재 여부뿐 아니라 위험한 조건부 재주행 표현도 확인.
        if not re.search(r"(?:안전.{0,12}정차|정차.{0,15}시동|시동.{0,10}(?:끄|정지))", article):
            issues.append("오일 압력 경고 시 신속한 안전 정차·시동 정지 순서 확인")
        if not re.search(r"(?:견인|긴급출동)", article):
            issues.append("오일 압력 경고 원인 미확인 시 견인·긴급출동 안내 누락")
        if not re.search(r"(?:보충|경고등).{0,110}(?:꺼져도|꺼졌더라도|사라져도|소등되더라도|원인.{0,15}확인)", article, re.S):
            issues.append("오일 보충·경고등 소등 후에도 원인 미확인 시 재주행 금지 안내 누락")
        if re.search(r"(?:휴게소까지|정비소까지|정비업체까지).{0,25}(?:주행|이동|운전)", article):
            issues.append("오일 압력 경고 시 먼 거리 계속 주행 권유 위험")
        if re.search(r"(?:오일량과|오일의).{0,12}(?:색상.{0,8})?점도(?:를|도)? 확인", article):
            issues.append("딥스틱으로 실제 오일 점도를 판단하는 듯한 설명")
    if "과열" in topic:
        if not re.search(r"(?:캡|뚜껑).{0,30}(?:열지|열면 안|열어서는 안)", article):
            issues.append("뜨거운 냉각계통 캡 개방 금지 문구 명확성 확인")
    return issues


def article_style_checks(article):
    """Detect repeated formal sentence endings; do not rewrite safety instructions mechanically."""
    formal = len(re.findall(r'(?:습니다|입니다|합니다|됩니다)(?:[.!?]|\s*$)', article, re.M))
    friendly = len(re.findall(r'(?:해요|돼요|예요|이에요|어요|아요|세요|네요|죠)(?:[.!?]|\s*$)', article, re.M))
    if formal >= 3 and formal / max(1, formal + friendly) > 0.2:
        return [f'문체 수정 필요: 보고서형 종결 {formal}개, 해요체 종결 {friendly}개. 본문을 자연스러운 해요체로 바꾸되 안전 지시는 명확하게 유지하세요.']
    return []


def validate_article(topic, article):
    """기계적 사전 점검: 의미/사실 검증을 보장하지 않음."""
    issues = article_style_checks(article)
    if len(article.strip()) < 700:
        issues.append("본문이 짧습니다. 설명과 주의사항을 확인하세요")
    if re.search(r"(?:무조건|반드시)\s*(?:더|높은|낮은)\s*점도", article):
        issues.append("점도가 높거나 낮을수록 무조건 좋다는 표현 확인")
    if "점도" in topic:
        for pattern, warning in (
            (r"5W.{0,35}(?:-30도|-30℃|영하 30)", "5W 저온 성능을 단일 온도로 단정"),
            (r"(?:점도가 높|높은 점도).{0,55}(?:마모를 줄|보호에 유리|좋)", "고점도가 무조건 엔진 보호에 유리하다는 표현"),
        ):
            if re.search(pattern, article, flags=re.I | re.S):
                issues.append(warning)
        if not any(x in article for x in ("API", "ACEA", "ILSAC", "제조사")):
            issues.append("제조사 요구 성능 규격 설명 누락")
    if "엔진오일" in topic and re.search(r"검은색.{0,35}(?:교환|교체)|검게.{0,30}(?:교환|교체)", article):
        issues.append("엔진오일 색만으로 교환 시기 판단 위험")
    if "과열" in topic:
        if not ("정차" in article and ("시동" in article or "엔진" in article)):
            issues.append("과열 경고 시 안전한 정차 및 시동 관련 조치 누락")
        if not ("캡" in article and ("뜨거" in article or "고온" in article or "식" in article)):
            issues.append("뜨거운 냉각계통 캡을 열지 말라는 화상 예방 안내 누락")
    if "엔진오일 경고등" in topic:
        if not ("정차" in article and "시동" in article and ("압력" in article or "유압" in article)):
            issues.append("빨간 엔진오일 압력 경고등: 정차·시동 정지·압력 경고 의미 설명 누락")
        if not any(x in article for x in ("견인", "정비소", "정비업체", "정비 전문가")):
            issues.append("경고 지속 시 재주행 금지 및 정비/견인 안내 확인")
    if is_urgent_warning_topic(topic):
        if re.search(r"(?:일단|우선|먼저).{0,24}(?:보충|구매|교환)", article):
            issues.append("긴급 경고 상황에서 보충·구매를 우선 안내하는지 검토")
    issues.extend(safety_semantic_checks(topic, article))
    return list(dict.fromkeys(issues))


def choose_product(products, keyword):
    """Conservative relevance filter; no product is preferable to a mismatched part."""
    if any(word in keyword for word in RESTRICTED_PART_TERMS) and not any(
        word in keyword for word in SAFE_KEYWORD_HINTS
    ):
        print("차종 호환성이 중요한 품목이므로 자동 상품 추천 생략:", keyword)
        return None
    tokens = [w for w in re.findall(r"[가-힣a-zA-Z0-9]+", keyword.lower())
              if len(w) >= 2 and w not in ("자동차", "차량용", "차량")]
    scored = []
    for product in products:
        name = str(product.get("productName", ""))
        compact_name = re.sub(r"\s+", "", name.lower())
        matched = sum(1 for token in tokens if token.replace(" ", "") in compact_name)
        if not matched or not format_price(product.get("productPrice")):
            continue
        scored.append((matched, product))
    if not scored:
        return None
    scored.sort(key=lambda pair: pair[0], reverse=True)
    return scored[0][1]


def insert_photo_markers(article):
    """Keep markers in one paste-ready file; do not create title/body duplicates."""
    blocks = [b.strip() for b in re.split(r"\n\s*\n", article) if b.strip()]
    if not blocks:
        return "[사진 1: 01_cover — 제목 아래]\n\n[사진 2: 02_article — 본문 중간]"
    # Insert the second image near the middle of the explanation, not the product section.
    position = min(max(2, len(blocks) // 2), len(blocks))
    blocks.insert(position, "[사진 2: 02_article — 본문 설명 사진 삽입]")
    return "[사진 1: 01_cover — 대표 사진 삽입]\n\n" + "\n\n".join(blocks)


def build_blog_post(topic, article, product, photo_sources=None, available_images=None):
    title = make_clean_title(topic)
    body = clean_blog_body(remove_repeated_heading(article, title, topic))
    body = insert_photo_markers(body)
    warnings = validate_article(topic, article)
    if warnings:
        body = "[발행 보류 — 아래 내용을 직접 확인하세요]\n" + "\n".join("• " + x for x in warnings) + "\n\n" + body
    disclosure = "이 포스팅은 쿠팡파트너스 활동의 일환으로, 이에 따른 일정액의 수수료를 제공받습니다."
    text = title + "\n\n" + (disclosure + "\n\n" if product else "") + body
    if product:
        price = format_price(product.get("productPrice"))
        text += ("\n\n관련 상품 안내\n"
                 "[사진 3: coupang_product — 상품 이미지 삽입]\n"
                 f"상품명: {product['productName']}\n"
                 + (f"검색 당시 가격: {price} (판매 가격은 변동될 수 있습니다)\n" if price else "")
                 + "구매 전 제품 규격과 차량 호환 여부를 확인하세요.\n"
                 + f"쿠팡파트너스 링크: {product['productUrl']}")
    if photo_sources:
        lines = []
        for info in photo_sources:
            if info.get("source") in ("Openverse", "Wikimedia Commons"):
                lines.append(f"• {info['filename']} / {info['source']} / 저작자: {info.get('photographer') or '원본 확인'} / "
                             f"라이선스: {info.get('license') or '원본 확인'} / 원본: {info.get('url') or ''} / "
                             f"라이선스 링크: {info.get('license_url') or ''}")
        if lines:
            text += "\n\n사진 출처 및 라이선스 (발행 전 원본 조건 확인)\n" + "\n".join(lines)
    if available_images is not None:
        for filename, marker in (("01_cover", "[사진 1:"), ("02_article", "[사진 2:"),
                                 ("coupang_product", "[사진 3:")):
            if not any(p.stem == filename or p.stem.startswith(filename + "_") for p in available_images):
                # Missing images must not be represented as available.
                text = re.sub(r"(?m)^" + re.escape(marker) + r"[^\n]*\n?", "", text)
    return text.strip() + "\n"


# 분야별 기준은 일반 안전 원칙이며 특정 차종의 제조사 매뉴얼을 대체하지 않습니다.
DOMAIN_RULES = {
    "타이어·휠": ("타이어", "휠", "공기압", "편마모", "얼라이먼트", "펑크", "트레드"),
    "엔진·윤활": ("엔진오일", "점도", "엔진", "오일 필터", "벨트"),
    "냉각·열관리": ("과열", "냉각수", "라디에이터", "수온", "부동액"),
    "브레이크·조향": ("브레이크", "제동", "패드", "디스크", "핸들", "조향"),
    "전기·배터리": ("배터리", "발전기", "퓨즈", "점프", "전압", "전조등", "상향등"),
    "세차·외장": ("세차", "코팅", "유막", "광택", "발수", "도장", "세정제"),
    "실내·공조": ("에어컨", "에바", "실내", "필터", "냄새", "히터"),
}
DOMAIN_GUIDANCE = {
    "타이어·휠": "냉간 공기압은 차량 제조사 지정값을 우선하고 타이어 측면 최대압을 권장 공기압으로 제시하지 마세요. 마모 한계·하중·규격·계절별 성능을 혼동하지 마세요. 휠 너트 토크는 차종별로 다릅니다.",
    "엔진·윤활": "누유 점검은 엔진을 끄고 충분히 식힌 후 안전한 위치에서 육안으로만 진행하세요. 회전 부품·뜨거운 배기 부품에 접근하지 말고 차량 아래로 들어가지 마세요. 누유 종류를 색이나 냄새만으로 확정하지 말고, 다량 누출·경고등·연기·화재 위험이 있으면 안전하게 운행을 중단하고 견인을 권하세요. 오일 압력 경고와 교환 알림을 구분하세요. SAE 점도 등급과 API/ACEA/ILSAC 등 성능 규격을 구분하고 차량별 승인 규격을 우선하세요. 색만으로 교환 시기를 판단하지 마세요.",
    "냉각·열관리": "과열 시 안전 정차, 화상 위험, 고온 냉각계통 캡 개방 금지, 냉각수 규격과 혼합 적합성을 강조하세요. 무리한 재주행을 권하지 마세요.",
    "브레이크·조향": "제동 성능 저하·경고등·조향 이상 시 운행 중단 및 정비/견인을 우선하세요. 부품 호환성·체결 토크·에어빼기 절차를 범용으로 단정하지 마세요.",
    "전기·배터리": "극성 오류, 합선, 화재 위험과 하이브리드/전기차 고전압 시스템을 구분하세요. 퓨즈 용량을 임의 증대하지 마세요. 차종별 점프시동 제한을 확인하세요.",
    "세차·외장": "도장면·유리·고무·가죽 등 소재별 적합성과 제품 라벨 지침을 우선하세요. 약품 혼합을 권하지 마세요. 코팅 지속 기간과 효과를 보장하지 마세요.",
    "실내·공조": "약품 흡입·전장부 침수 위험을 안내하고 에어백·센서·고전압 부품 주변 작업은 전문가에게 맡기세요. 소독·살균 효과를 근거 없이 단정하지 마세요.",
}



DOMAIN_GUIDANCE.update({"하체·서스펜션": "차량 하부에 들어가지 말고 리프트 및 지지장치 없이 작업하지 마세요. 소음만으로 부품 고장을 단정하지 마세요. 조향·현가 불안정 시 운행을 줄이고 전문점 점검을 권하세요.", "변속기·구동": "변속기 오일 규격·레벨 측정 절차는 차종마다 다릅니다. DPF 경고등에 임의 고속 주행이나 첨가제를 보편적 해결책으로 권하지 마세요.", "전기·전자": "회로 단락과 에어백 전장 위험을 주의하고 퓨즈 용량 임의 증대를 금지하세요. 차종별 전자장치 초기화 절차를 단정하지 마세요.", "안전·운행": "운전자·탑승자 생명 안전이 우선입니다. 갓길 정차 시 차로 진입이나 위험한 삼각대 설치를 권하지 마세요. 침수 차량은 임의 시동 금지. 졸음운전은 즉시 안전한 장소에서 휴식하세요."})

# 주제 전체 진단 기반 보정 테이블 (topic_audit.json 114개 기준)
TOPIC_OVERRIDES = {'엔진룸 누유 흔적 확인 방법': {'domain': '엔진·윤활',
                     'risk': '보통',
                     'affiliate': '추천 없음 (안전 안내 우선)',
                     'image_query': 'engine oil leak under car engine bay'},
 '자동차 과열 경고가 뜰 때 안전하게 대처하는 방법': {'domain': '냉각·열관리',
                                 'risk': '높음',
                                 'affiliate': '추천 없음 (안전 안내 우선)',
                                 'image_query': 'engine temperature warning light dashboard car'},
 '브레이크액 점검과 교환 시 주의사항': {'domain': '브레이크·조향',
                         'risk': '높음',
                         'affiliate': '자동차 브레이크액',
                         'image_query': 'car brake fluid reservoir'},
 '자동차 퓨즈 역할과 확인 시 주의사항': {'domain': '전기·전자', 'risk': '보통', 'affiliate': '자동차 퓨즈', 'image_query': 'car fuse box'},
 '자동차 실내등 관리와 교체 시 주의사항': {'domain': '실내·공조',
                           'risk': '일반',
                           'affiliate': '자동차 실내등',
                           'image_query': 'car interior dome light'},
 '자동차 세차 버킷 관리 방법': {'domain': '세차·외장',
                     'risk': '일반',
                     'affiliate': '세차 버킷',
                     'image_query': 'car wash bucket grit guard detailing'},
 '자동차 휠 세정제 선택 시 주의사항': {'domain': '세차·외장',
                         'risk': '일반',
                         'affiliate': '자동차 휠 클리너',
                         'image_query': 'applying wheel cleaner to alloy wheel'},
 '엔진룸 먼지 관리 시 주의사항': {'domain': '엔진·윤활',
                      'risk': '일반',
                      'affiliate': '엔진룸 청소용품',
                      'image_query': 'dusty car engine bay cleaning'},
 '냉각수 부족 징후와 점검 요령': {'domain': '냉각·열관리',
                      'risk': '보통',
                      'affiliate': '자동차 냉각수',
                      'image_query': 'car engine coolant reservoir'},
 '냉각수 색상만으로 상태를 판단하면 안 되는 이유': {'domain': '냉각·열관리',
                                'risk': '보통',
                                'affiliate': '자동차 냉각수',
                                'image_query': 'car engine coolant reservoir'},
 '워터펌프 이상 징후와 점검 포인트': {'domain': '냉각·열관리',
                        'risk': '보통',
                        'affiliate': '추천 없음 (정보·안전 안내 우선)',
                        'image_query': 'automotive water pump removed from engine'},
 '구동벨트 마모를 의심할 수 있는 소리와 증상': {'domain': '엔진·윤활',
                              'risk': '보통',
                              'affiliate': '자동차 벨트',
                              'image_query': 'car serpentine drive belt engine pulley'},
 '시동 직후 엔진 소음 점검 체크리스트': {'domain': '엔진·윤활',
                          'risk': '일반',
                          'affiliate': '자동차 엔진오일',
                          'image_query': 'mechanic inspecting car engine compartment'},
 '엔진오일 교환 후 확인할 사항': {'domain': '엔진·윤활',
                      'risk': '보통',
                      'affiliate': '엔진오일',
                      'image_query': 'car engine oil change'},
 '차량별 엔진오일 규격을 확인하는 방법': {'domain': '엔진·윤활',
                          'risk': '보통',
                          'affiliate': '엔진오일',
                          'image_query': 'automotive engine oil bottle'},
 '엔진룸에서 탄 냄새가 날 때 확인할 부분': {'domain': '엔진·윤활',
                            'risk': '보통',
                            'affiliate': '자동차 엔진룸 점검',
                            'image_query': 'car engine bay burnt wiring inspection'},
 '브레이크 페달이 평소보다 깊게 들어갈 때': {'domain': '브레이크·조향',
                            'risk': '높음',
                            'affiliate': '추천 없음 (안전 안내 우선)',
                            'image_query': 'car brake disc caliper'},
 '제동 시 차가 한쪽으로 쏠리는 원인': {'domain': '브레이크·조향',
                         'risk': '높음',
                         'affiliate': '추천 없음 (안전 안내 우선)',
                         'image_query': 'car brake caliper inspection on lift'},
 '브레이크 디스크 변형 의심 증상': {'domain': '브레이크·조향',
                       'risk': '높음',
                       'affiliate': '추천 없음 (정보·안전 안내 우선)',
                       'image_query': 'car brake disc caliper'},
 '브레이크 소음 종류별 점검 포인트': {'domain': '브레이크·조향',
                        'risk': '높음',
                        'affiliate': '추천 없음 (정보·안전 안내 우선)',
                        'image_query': 'car brake disc caliper'},
 '주행 중 하체에서 덜컹거리는 소리의 원인': {'domain': '하체·서스펜션',
                            'risk': '보통',
                            'affiliate': '추천 없음 (정보·안전 안내 우선)',
                            'image_query': 'car suspension undercarriage inspection'},
 '과속방지턱 통과 시 소음 점검법': {'domain': '하체·서스펜션',
                       'risk': '보통',
                       'affiliate': '추천 없음 (정보·안전 안내 우선)',
                       'image_query': 'car suspension strut inspection'},
 '쇼크업소버 이상 징후 알아보기': {'domain': '하체·서스펜션',
                      'risk': '보통',
                      'affiliate': '추천 없음 (정보·안전 안내 우선)',
                      'image_query': 'car shock absorber suspension strut'},
 '로어암 부싱 마모 증상과 점검 방법': {'domain': '하체·서스펜션',
                         'risk': '보통',
                         'affiliate': '자동차 하체 부싱',
                         'image_query': 'car lower control arm bushing'},
 '스태빌라이저 링크 이상 증상': {'domain': '하체·서스펜션',
                     'risk': '보통',
                     'affiliate': '추천 없음 (정보·안전 안내 우선)',
                     'image_query': 'car stabilizer sway bar link'},
 '핸들 떨림이 발생할 때 점검 순서': {'domain': '브레이크·조향',
                        'risk': '보통',
                        'affiliate': '추천 없음 (정보·안전 안내 우선)',
                        'image_query': 'car steering wheel vibration inspection'},
 '고속 주행 시 차체 진동의 주요 원인': {'domain': '하체·서스펜션',
                          'risk': '보통',
                          'affiliate': '추천 없음 (정보·안전 안내 우선)',
                          'image_query': 'car wheel balancing machine tire'},
 '주차 후 바닥에 액체가 떨어졌을 때 구분법': {'domain': '엔진·윤활',
                             'risk': '보통',
                             'affiliate': '자동차 누유 점검',
                             'image_query': 'fluid puddle beneath parked car'},
 '자동차 하부 부식 예방 관리법': {'domain': '세차·외장',
                      'risk': '일반',
                      'affiliate': '자동차 언더코팅',
                      'image_query': 'rusty car undercarriage inspection'},
 '퓨즈가 반복해서 끊어질 때 확인할 점': {'domain': '전기·전자', 'risk': '보통', 'affiliate': '자동차 퓨즈', 'image_query': 'car fuse box'},
 '블랙박스 메모리카드 관리 방법': {'domain': '전기·전자',
                      'risk': '일반',
                      'affiliate': '블랙박스 메모리카드',
                      'image_query': 'car dashcam memory card'},
 '후미등이 들어오지 않을 때 점검 순서': {'domain': '전기·전자',
                          'risk': '일반',
                          'affiliate': '자동차 후미등 전구',
                          'image_query': 'car rear taillight lamp'},
 '방향지시등 점멸 속도가 빨라졌을 때': {'domain': '전기·전자',
                         'risk': '일반',
                         'affiliate': '자동차 방향지시등 전구',
                         'image_query': 'car turn signal light'},
 '자동차 USB 충전기 선택 시 확인 사항': {'domain': '전기·전자',
                            'risk': '일반',
                            'affiliate': '차량용 USB 충전기',
                            'image_query': 'car USB charger in dashboard'},
 '자동차 시거잭 전원 사용 시 주의사항': {'domain': '전기·전자',
                          'risk': '일반',
                          'affiliate': '차량용 시거잭',
                          'image_query': 'car 12v accessory socket'},
 '자동차 경적이 작동하지 않을 때 점검 항목': {'domain': '전기·전자',
                             'risk': '일반',
                             'affiliate': '자동차 퓨즈',
                             'image_query': 'car steering wheel horn button'},
 '계기판 경고등 색깔별 대응 원칙': {'domain': '안전·운행',
                       'risk': '높음',
                       'affiliate': '추천 없음 (정보·안전 안내 우선)',
                       'image_query': 'car dashboard illuminated warning indicators'},
 '차량 전자장치 초기화가 필요한 상황': {'domain': '전기·전자',
                         'risk': '일반',
                         'affiliate': '자동차 OBD2 스캐너',
                         'image_query': 'car diagnostic scan tool connected OBD port'},
 '후방카메라 화면이 흐릴 때 관리 방법': {'domain': '전기·전자',
                          'risk': '일반',
                          'affiliate': '후방카메라 클리너',
                          'image_query': 'dirty car rear view camera lens'},
 '자동차 문짝 고무 몰딩 관리 방법': {'domain': '세차·외장',
                        'risk': '일반',
                        'affiliate': '자동차 고무 몰딩 보호제',
                        'image_query': 'car rubber door weatherstrip'},
 '도어 힌지 소음 관리와 윤활 주의사항': {'domain': '세차·외장',
                          'risk': '일반',
                          'affiliate': '자동차 힌지 윤활제',
                          'image_query': 'car door hinge close up'},
 '자동차 도어 잠금장치 관리 방법': {'domain': '세차·외장',
                       'risk': '일반',
                       'affiliate': '자동차 도어 윤활제',
                       'image_query': 'car door latch mechanism'},
 '트렁크 누수 흔적 확인하는 방법': {'domain': '실내·공조',
                       'risk': '일반',
                       'affiliate': '자동차 방수 테이프',
                       'image_query': 'water leak in car trunk carpet'},
 '자동차 도장면 미세 흠집 관리법': {'domain': '세차·외장',
                       'risk': '일반',
                       'affiliate': '자동차 컴파운드',
                       'image_query': 'fine swirl scratches on car paint close up'},
 '차량 도장면 새똥 제거 시 주의사항': {'domain': '세차·외장',
                         'risk': '일반',
                         'affiliate': '추천 없음 (정보 안내 우선)',
                         'image_query': 'bird droppings on car paint close up'},
 '차량 도장면 벌레 자국 제거 방법': {'domain': '세차·외장',
                        'risk': '일반',
                        'affiliate': '자동차 버그 클리너',
                        'image_query': 'insect residue on car front bumper'},
 '자동차 외장 크롬 몰딩 관리법': {'domain': '세차·외장',
                      'risk': '일반',
                      'affiliate': '자동차 크롬 클리너',
                      'image_query': 'car chrome trim close up'},
 '자동차 번호판 주변 오염 관리법': {'domain': '세차·외장',
                       'risk': '일반',
                       'affiliate': '자동차 세차 브러쉬',
                       'image_query': 'dirty car license plate surround'},
 '차량 루프랙 관리와 적재 주의사항': {'domain': '세차·외장',
                        'risk': '일반',
                        'affiliate': '자동차 루프랙',
                        'image_query': 'car roof rack cross bars'},
 '자동차 범퍼 긁힘 관리 시 주의사항': {'domain': '세차·외장',
                         'risk': '일반',
                         'affiliate': '자동차 컴파운드',
                         'image_query': 'scratched car bumper close up'},
 '자동차 문콕 예방을 위한 주차 습관': {'domain': '세차·외장',
                         'risk': '일반',
                         'affiliate': '자동차 도어가드',
                         'image_query': 'car door parking lot close up'},
 '자동차 선루프 배수구 관리 시 주의사항': {'domain': '세차·외장',
                           'risk': '일반',
                           'affiliate': '자동차 청소 브러쉬',
                           'image_query': 'car sunroof drainage channel'},
 '자동차 시트 재질별 관리 방법': {'domain': '실내·공조',
                      'risk': '일반',
                      'affiliate': '자동차 시트 클리너',
                      'image_query': 'car seat upholstery materials'},
 '가죽 시트 관리에서 피해야 할 행동': {'domain': '실내·공조',
                         'risk': '일반',
                         'affiliate': '자동차 가죽 클리너',
                         'image_query': 'car leather seat cleaning'},
 '패브릭 시트 얼룩 관리법': {'domain': '실내·공조',
                   'risk': '일반',
                   'affiliate': '패브릭 시트 클리너',
                   'image_query': 'car fabric upholstery stain'},
 '차량 바닥매트 세척과 건조 방법': {'domain': '실내·공조',
                       'risk': '일반',
                       'affiliate': '자동차 매트 클리너',
                       'image_query': 'car floor mat cleaning'},
 '자동차 안전벨트 오염 관리법': {'domain': '실내·공조',
                     'risk': '일반',
                     'affiliate': '자동차 실내 클리너',
                     'image_query': 'car seat belt webbing cleaning'},
 '자동차 핸들 오염 관리와 주의사항': {'domain': '실내·공조',
                        'risk': '일반',
                        'affiliate': '자동차 실내 클리너',
                        'image_query': 'car steering wheel surface cleaning'},
 '차량 컵홀더 틈새 청소 방법': {'domain': '실내·공조',
                     'risk': '일반',
                     'affiliate': '자동차 틈새 브러쉬',
                     'image_query': 'dirty car cup holder cleaning'},
 '자동차 송풍구 먼지 관리법': {'domain': '실내·공조',
                    'risk': '일반',
                    'affiliate': '자동차 송풍구 브러쉬',
                    'image_query': 'car air vent cleaning brush'},
 '차량 실내 결로와 습기 줄이는 습관': {'domain': '실내·공조',
                         'risk': '일반',
                         'affiliate': '차량용 제습제',
                         'image_query': 'condensation on car interior windshield'},
 '자동차 실내 플라스틱 변색 관리법': {'domain': '실내·공조',
                        'risk': '일반',
                        'affiliate': '자동차 실내 보호제',
                        'image_query': 'faded car interior plastic trim'},
 '차량용 방향제 선택 시 확인할 점': {'domain': '실내·공조',
                        'risk': '일반',
                        'affiliate': '차량용 방향제',
                        'image_query': 'car air freshener dashboard'},
 '차량 시트 포지션을 올바르게 조절하는 방법': {'domain': '안전·운행',
                             'risk': '일반',
                             'affiliate': '추천 없음 (정보·안전 안내 우선)',
                             'image_query': 'driver seat adjustment controls'},
 '자동차 헤드레스트 조절 방법': {'domain': '안전·운행',
                     'risk': '일반',
                     'affiliate': '추천 없음 (정보·안전 안내 우선)',
                     'image_query': 'car head restraint adjustment'},
 '차량용 휴대전화 거치대 설치 시 주의사항': {'domain': '실내·공조',
                            'risk': '일반',
                            'affiliate': '차량용 휴대폰 거치대',
                            'image_query': 'car phone mount dashboard'},
 '겨울철 자동차 성에 제거 시 주의사항': {'domain': '세차·외장',
                          'risk': '일반',
                          'affiliate': '자동차 성에 제거기',
                          'image_query': 'frost on car windshield scraper'},
 '겨울철 도어 손잡이가 얼었을 때 대처법': {'domain': '세차·외장',
                           'risk': '일반',
                           'affiliate': '자동차 성에 제거제',
                           'image_query': 'frozen car door handle winter'},
 '폭염에 주차한 차량 탑승 전 점검사항': {'domain': '안전·운행',
                          'risk': '일반',
                          'affiliate': '자동차 햇빛가리개',
                          'image_query': 'car interior dashboard under summer sun'},
 '여름철 차량 실내 물품 보관 주의사항': {'domain': '실내·공조',
                          'risk': '일반',
                          'affiliate': '자동차 정리함',
                          'image_query': 'car interior items under sunlight'},
 '장거리 운전 전 차량 점검 체크리스트': {'domain': '안전·운행',
                          'risk': '일반',
                          'affiliate': '자동차 비상용품',
                          'image_query': 'car tire pressure check before road trip'},
 '고속도로 갓길 정차 시 안전 수칙': {'domain': '안전·운행',
                        'risk': '높음',
                        'affiliate': '추천 없음 (정보·안전 안내 우선)',
                        'image_query': 'car emergency stop highway shoulder'},
 '차량용 소화기 선택과 비치 방법': {'domain': '안전·운행',
                       'risk': '높음',
                       'affiliate': '차량용 소화기',
                       'image_query': 'vehicle fire extinguisher in car'},
 '자동차 비상탈출 도구 사용 전 알아둘 점': {'domain': '안전·운행',
                            'risk': '높음',
                            'affiliate': '차량용 비상탈출 망치',
                            'image_query': 'car emergency window escape hammer'},
 '야간 운전 시 눈부심을 줄이는 운전 습관': {'domain': '안전·운행',
                            'risk': '일반',
                            'affiliate': '자동차 선바이저',
                            'image_query': 'night driving view through windshield'},
 '안개 낀 날 운전 전 확인할 사항': {'domain': '안전·운행',
                        'risk': '높음',
                        'affiliate': '자동차 안개등',
                        'image_query': 'car driving in fog low visibility'},
 '차량 침수 후 시동을 걸면 안 되는 이유': {'domain': '안전·운행',
                            'risk': '높음',
                            'affiliate': '추천 없음 (정보·안전 안내 우선)',
                            'image_query': 'flood damaged parked car'},
 '눈길 주행 후 차량 관리 체크리스트': {'domain': '안전·운행',
                         'risk': '일반',
                         'affiliate': '자동차 하부 세차용품',
                         'image_query': 'salt covered car undercarriage winter'},
 '장거리 운전 시 졸음운전 예방 습관': {'domain': '안전·운행',
                         'risk': '일반',
                         'affiliate': '추천 없음 (정보·안전 안내 우선)',
                         'image_query': 'driver resting at highway rest area'},
 '초보 운전자를 위한 차량 비상용품 목록': {'domain': '안전·운행',
                           'risk': '일반',
                           'affiliate': '자동차 비상용품',
                           'image_query': 'car emergency roadside kit'},
 '장기간 주차할 때 차량 관리 체크리스트': {'domain': '안전·운행',
                           'risk': '일반',
                           'affiliate': '자동차 차량 커버',
                           'image_query': 'parked car with protective cover'},
 '자동차 연비가 갑자기 나빠졌을 때 점검 항목': {'domain': '안전·운행',
                              'risk': '일반',
                              'affiliate': '추천 없음 (정보·안전 안내 우선)',
                              'image_query': 'car fuel economy display dashboard'},
 '급가속과 급제동이 연비에 미치는 영향': {'domain': '안전·운행',
                          'risk': '높음',
                          'affiliate': '추천 없음 (정보·안전 안내 우선)',
                          'image_query': 'car fuel economy dashboard gauge'},
 '공회전 습관과 연료 소비 알아보기': {'domain': '안전·운행',
                        'risk': '일반',
                        'affiliate': '추천 없음 (정보·안전 안내 우선)',
                        'image_query': 'car tachometer at idle'},
 '자동차 연료 주입 시 주의사항': {'domain': '안전·운행',
                      'risk': '보통',
                      'affiliate': '추천 없음 (정보·안전 안내 우선)',
                      'image_query': 'car fuel nozzle at gas station'},
 '차량에 불필요한 짐을 줄여야 하는 이유': {'domain': '안전·운행',
                           'risk': '일반',
                           'affiliate': '자동차 트렁크 정리함',
                           'image_query': 'car trunk luggage storage'},
 '크루즈컨트롤 사용 시 주의사항': {'domain': '안전·운행',
                      'risk': '일반',
                      'affiliate': '추천 없음 (정보·안전 안내 우선)',
                      'image_query': 'car cruise control steering wheel buttons'},
 '자동차 변속 충격을 느낄 때 점검 사항': {'domain': '변속기·구동',
                           'risk': '보통',
                           'affiliate': '추천 없음 (정보·안전 안내 우선)',
                           'image_query': 'car automatic transmission gear selector'},
 '자동변속기 오일 점검 시 확인할 것': {'domain': '변속기·구동',
                         'risk': '보통',
                         'affiliate': '추천 없음 (정보·안전 안내 우선)',
                         'image_query': 'automatic transmission fluid service'},
 '디젤 차량 DPF 경고등의 의미와 대처법': {'domain': '엔진·윤활',
                            'risk': '높음',
                            'affiliate': '추천 없음 (정보·안전 안내 우선)',
                            'image_query': 'diesel particulate filter warning dashboard'},
 '디젤 차량 요소수 보충 시 주의사항': {'domain': '엔진·윤활',
                         'risk': '일반',
                         'affiliate': '자동차 요소수',
                         'image_query': 'diesel AdBlue DEF filler cap'},
 '자동차 주행거리별 점검 항목 정리': {'domain': '안전·운행',
                        'risk': '일반',
                        'affiliate': '자동차 정비 수첩',
                        'image_query': 'car odometer dashboard'},
 '자동차 정기검사 전 확인할 사항': {'domain': '안전·운행',
                       'risk': '일반',
                       'affiliate': '자동차 OBD2 스캐너',
                       'image_query': 'vehicle inspection mechanic checking car'},
 '폼랜스와 폼건의 차이 알아보기': {'domain': '세차·외장',
                      'risk': '일반',
                      'affiliate': '자동차 폼건',
                      'image_query': 'car wash foam lance pressure washer'},
 '세차용 브러시를 부위별로 구분해야 하는 이유': {'domain': '세차·외장',
                              'risk': '일반',
                              'affiliate': '자동차 세차 브러쉬',
                              'image_query': 'different car detailing brushes wheel interior'},
 '차량 틈새 물기 제거하는 방법': {'domain': '세차·외장',
                      'risk': '일반',
                      'affiliate': '자동차 드라잉 에어건',
                      'image_query': 'car detailing air blower drying'},
 '세차용품 보관과 건조 방법': {'domain': '세차·외장',
                    'risk': '일반',
                    'affiliate': '세차용품 정리함',
                    'image_query': 'car wash microfiber towels brushes drying rack'},
 '자동차 왁스와 실런트 차이점': {'domain': '세차·외장',
                     'risk': '일반',
                     'affiliate': '자동차 왁스',
                     'image_query': 'car paint wax applicator'},
 '자동차 퀵디테일러 사용 시 주의사항': {'domain': '세차·외장',
                         'risk': '일반',
                         'affiliate': '자동차 퀵디테일러',
                         'image_query': 'car quick detailer spray microfiber'},
 '자동차 타르 오염 제거 시 주의사항': {'domain': '세차·외장',
                         'risk': '일반',
                         'affiliate': '자동차 타르 제거제',
                         'image_query': 'car paint tar spots close up'},
 '세차용 스프레이 용기 라벨 관리 방법': {'domain': '세차·외장',
                          'risk': '일반',
                          'affiliate': '세차용 스프레이 용기',
                          'image_query': 'labeled car detailing spray bottles shelf'},
 '겨울철 세차 시 물이 얼지 않도록 주의할 점': {'domain': '세차·외장',
                              'risk': '일반',
                              'affiliate': '자동차 세차용품',
                              'image_query': 'car washing in freezing winter weather'},
 '차량 하부 세차가 필요한 상황': {'domain': '세차·외장',
                      'risk': '일반',
                      'affiliate': '자동차 하부 세차기',
                      'image_query': 'washing car undercarriage underbody rinse'},
 '타이어 옆면 손상 발견 시 대처 방법': {'domain': '타이어·휠',
                          'risk': '높음',
                          'affiliate': '추천 없음 (정보·안전 안내 우선)',
                          'image_query': 'damaged tire sidewall bulge crack close up'},
 '타이어 트레드 홈에 낀 돌 제거 시 주의사항': {'domain': '타이어·휠',
                              'risk': '보통',
                              'affiliate': '타이어 홈 청소 도구',
                              'image_query': 'small stones stuck in tire tread grooves close up'},
 '타이어 수리 가능 여부를 판단할 때 확인할 것': {'domain': '타이어·휠',
                               'risk': '보통',
                               'affiliate': '추천 없음 (정보·안전 안내 우선)',
                               'image_query': 'puncture nail in tire tread inspection close up'},
 '타이어 사이즈 표기 읽는 방법': {'domain': '타이어·휠',
                      'risk': '보통',
                      'affiliate': '추천 없음 (정보·안전 안내 우선)',
                      'image_query': 'tire sidewall size markings close up'},
 '타이어 하중지수와 속도등급의 의미': {'domain': '타이어·휠',
                        'risk': '보통',
                        'affiliate': '추천 없음 (정보·안전 안내 우선)',
                        'image_query': 'tire sidewall load index speed rating markings'},
 '휠 너트 체결 토크가 중요한 이유': {'domain': '타이어·휠',
                        'risk': '높음',
                        'affiliate': '자동차 토크렌치',
                        'image_query': 'mechanic tightening car wheel lug nuts torque wrench'},
 '스페어타이어 점검과 보관 방법': {'domain': '타이어·휠',
                      'risk': '보통',
                      'affiliate': '자동차 공기압 측정기',
                      'image_query': 'spare tire in car trunk storage compartment'},
 '타이어 밸브캡 관리와 분실 시 주의사항': {'domain': '타이어·휠',
                           'risk': '보통',
                           'affiliate': '타이어 밸브캡',
                           'image_query': 'tire valve stem cap close up wheel'},
 '휠 림 손상 발견 시 점검 방법': {'domain': '타이어·휠',
                       'risk': '높음',
                       'affiliate': '추천 없음 (정보·안전 안내 우선)',
                       'image_query': 'bent cracked alloy wheel rim close up'},
 '타이어 소음이 커졌을 때 확인할 사항': {'domain': '타이어·휠',
                          'risk': '보통',
                          'affiliate': '타이어 트레드 측정기',
                          'image_query': 'uneven tire tread cupping wear close up'},
 '타이어 펑크 의심 시 안전하게 정차하는 방법': {'domain': '타이어·휠',
                              'risk': '높음',
                              'affiliate': '추천 없음 (안전 안내 우선)',
                              'image_query': 'car flat tire safely stopped roadside'}}


# Additional explicit mappings for the 15 topics identified by the offline audit.
TOPIC_OVERRIDES.update({'자동차 타이어 공기압 올바르게 관리하는 방법': {'domain': '타이어·휠', 'risk': '보통', 'affiliate': '자동차 공기주입기', 'image_query': 'car tire pressure gauge checking valve'}, '자동차 와이퍼 교체 시기와 관리법': {'domain': '시야·유리', 'risk': '일반', 'affiliate': '자동차 와이퍼', 'image_query': 'car windshield wiper blade close up'}, '타이어 편마모 원인과 점검 방법': {'domain': '타이어·휠', 'risk': '보통', 'affiliate': '타이어 공기압 측정기', 'image_query': 'uneven tire tread wear close up'}, '자동차 타이어 교체 시기 확인 방법': {'domain': '타이어·휠', 'risk': '보통', 'affiliate': '타이어 트레드 측정기', 'image_query': 'worn car tire tread wear indicator close up'}, '여름철 타이어 관리에서 주의할 점': {'domain': '타이어·휠', 'risk': '보통', 'affiliate': '타이어 공기주입기', 'image_query': 'car tire summer tread inspection'}, '겨울철 타이어 관리와 안전 운전 요령': {'domain': '타이어·휠', 'risk': '보통', 'affiliate': '타이어 공기압 측정기', 'image_query': 'winter car tire snow tread close up'}, '자동차 실내 먼지 청소 방법': {'domain': '실내·공조', 'risk': '일반', 'affiliate': '차량용 청소기', 'image_query': 'vacuum cleaning car interior dashboard dust'}, '자동차 세차 후 물자국 줄이는 방법': {'domain': '세차·외장', 'risk': '일반', 'affiliate': '세차 드라잉타월', 'image_query': 'drying washed car paint microfiber towel water spots'}, '자동차 세차용 타월 종류와 사용법': {'domain': '세차·외장', 'risk': '일반', 'affiliate': '세차 극세사 타월', 'image_query': 'car detailing microfiber drying towels'}, '자동차 에어컨 필터 관리 방법': {'domain': '실내·공조', 'risk': '일반', 'affiliate': '자동차 에어컨 필터', 'image_query': 'car cabin air filter inspection'}, '자동차 실내 냄새 관리 시 주의사항': {'domain': '실내·공조', 'risk': '일반', 'affiliate': '자동차 실내 클리너', 'image_query': 'cleaning car interior upholstery ventilation'}, '장마철 차량 관리 체크리스트': {'domain': '안전·운행', 'risk': '일반', 'affiliate': '자동차 유리 발수코팅제', 'image_query': 'car windshield visibility heavy rain wipers'}, '자동차 트렁크 정리와 비상용품 점검': {'domain': '수납·비상용품', 'risk': '일반', 'affiliate': '자동차 트렁크 정리함', 'image_query': 'car trunk emergency kit organized storage'}, '차량 외장 플라스틱 관리 방법': {'domain': '세차·외장', 'risk': '일반', 'affiliate': '자동차 플라스틱 복원제', 'image_query': 'car exterior black plastic trim close up'}, '타이어 공기압 측정기를 올바르게 사용하는 방법': {'domain': '타이어·휠', 'risk': '보통', 'affiliate': '타이어 공기압 측정기', 'image_query': 'car tire pressure gauge valve measurement close up'}})
DOMAIN_GUIDANCE.update({"시야·유리":"시야 확보와 차종별 와이퍼 규격을 우선하세요. 운행 중 조작·정비를 권하지 마세요.", "수납·비상용품":"화물 고정, 적재 한도, 비상용품 상태를 확인하세요. 비상 상황에서 위험한 차로 진입을 권하지 마세요."})

DOMAIN_GUIDANCE['냉각·열관리'] += (
    ' 냉각수 색상은 규격·호환성·성능을 보증하지 않습니다. '
    '농도·동결점 검사만으로 부식 억제 성능과 전체 냉각계통 상태를 확정하지 마세요. '
    '단순 보충과 배출·교환·정비 후 공기 제거 절차를 구분하고 모든 보충에 에어빼기가 필수라고 단정하지 마세요. '
    '과열 시 우선 안전한 장소에 정차하고 이후 조치는 해당 차량 사용설명서와 긴급출동 안내를 따르도록 하세요. '
    '모든 차량에 동일한 시동·냉각 절차나 손상 진행 속도를 단정하지 마세요. '
    '엔진이 꺼져도 냉각팬이 작동할 수 있으며 고온·가압 상태의 캡은 열지 않도록 명확히 안내하세요.'
)

def classify_domain(topic):
    override = TOPIC_OVERRIDES.get(topic)
    if override:
        return override["domain"]
    counts = {name: sum(topic.count(word) for word in words) for name, words in DOMAIN_RULES.items()}
    return max(counts, key=counts.get) if max(counts.values(), default=0) else "일반 자동차 관리"


def topic_safety_tier(topic):
    override = TOPIC_OVERRIDES.get(topic)
    if override:
        return override["risk"]
    if is_urgent_warning_topic(topic) or any(x in topic for x in ("브레이크", "제동", "고전압", "화재", "에어백", "펑크", "조향", "경고등")):
        return "높음"
    if any(x in topic for x in ("오일", "냉각수", "배터리", "퓨즈", "타이어", "얼라이먼트", "누유", "누출", "액체가 떨어")):
        return "보통"
    return "일반"


def domain_static_checks(topic, article):
    issues = []
    if any(word in topic for word in ('냉각수', '과열', '냉각계통')):
        for sentence in re.split(r'[.!?\n]', article):
            if re.search(r'보충.{0,70}(?:에어\s*빼기|공기\s*빼기|공기\s*제거).{0,35}(?:해야|필수|반드시)', sentence):
                if not re.search(r'필요한\s*경우|일부\s*차량|차량에\s*따라|(?:매뉴얼|제조사).{0,30}요구.{0,10}경우', sentence):
                    issues.append('냉각수 단순 보충에도 에어빼기가 항상 필요하다는 단정: 차종과 작업 범위에 따른 제조사 절차를 구분하세요.')
                    break
    patterns = [
        (r"(?:타이어\s*측면|사이드월).{0,45}(?:최대\s*공기압|MAX\s*PRESSURE).{0,30}(?:맞추|주입|유지|권장)", "타이어 측면 최대 공기압을 권장값으로 오인할 가능성"),
        (r"(?:퓨즈|휴즈).{0,35}(?:더\s*높은|큰\s*용량|용량을\s*높여)", "퓨즈 용량 임의 변경 위험"),
        (r"(?:뜨거운|고온).{0,20}(?:냉각수|라디에이터).{0,20}(?:캡|뚜껑).{0,12}(?:열|개방)", "뜨거운 냉각계통 캡 개방 표현 확인"),
        (r"(?:모든\s*차량|어떤\s*차든).{0,35}(?:동일|호환|적용|가능)", "차종별 차이를 무시한 단정 표현"),
        (r"(?:100%|완벽하게|영구적|절대\s*고장\s*없)", "근거 없는 절대적 성능 표현"),
    ]
    for pattern, message in patterns:
        for sentence in re.split(r'[.!?\n]', article):
            if re.search(pattern, sentence, re.I):
                # Negative warnings must not repeatedly trigger paid revisions.
                if message == "뜨거운 냉각계통 캡 개방 표현 확인" and re.search(
                        r'(?:캡|뚜껑).{0,20}(?:열지\s*(?:마|않)|열면\s*안|열어서는\s*안|개방하지\s*마)', sentence):
                    continue
                issues.append(message)
                break
    if any(x in topic for x in ("누유", "오일 누출", "액체가 떨어")):
        if not any(x in article for x in ("시동을 끄", "시동을 끈", "시동을 꺼", "엔진을 끄", "엔진을 꺼", "엔진을 정지")):
            issues.append("누유 점검 전 시동 정지 안내 누락")
        if not any(x in article for x in ("식힌", "식은", "뜨거운", "고온", "화상")):
            issues.append("누유 점검 시 뜨거운 엔진·배기부품 화상 위험 안내 누락")
        if not any(x in article for x in ("회전", "벨트", "팬")):
            issues.append("엔진 회전 부품 접근 금지 안내 누락")
        if not any(x in article for x in ("견인", "운행 중단", "운행을 중단", "주행 중단")):
            issues.append("심각한 누유·경고등 시 운행 중단 또는 견인 안내 누락")
        # 문장 단위로 확인해 '들어가지 마세요' 등 금지 문구는 위험 권고로 오인하지 않는다.
        for sentence in re.split(r"[.!?\n]|(?:다\.|요\.)", article):
            if re.search(r"(?:차량|자동차)\s*아래(?:에|로)\s*(?:들어가|기어)", sentence):
                if not re.search(r"(?:금지|피하|않|말아|마세요|안\s*됩|위험|해서는\s*안|하지\s*마)", sentence):
                    issues.append("차량 하부 진입을 권고하는 표현 확인 필요")
                    break
    if topic_safety_tier(topic) == "높음" and not any(x in article for x in ("정비", "전문가", "제조사", "매뉴얼", "사용설명서")):
        issues.append("안전 중요 주제에 전문 정비/매뉴얼 안내 누락")
    return issues


def expert_review(client, topic, article):
    """독립 모델 검토. 확인 가능한 외부 문헌을 실제 조회하는 기능은 아닙니다."""
    domain = classify_domain(topic)
    prompt = ("당신은 보수적인 자동차 정비 기술 검토자입니다. 작성자가 아니라 독립 검토자처럼 평가하세요. "
              "이 검토에는 인터넷 검색이나 제조사 문서 열람이 제공되지 않습니다. 확인하지 못한 사실을 검증했다고 주장하지 마세요. "
              "안전 위험, 잘못된 정비 방법, 근거 없는 수치/주기/토크/규격, 차종별 차이 누락, 부정확한 전문 용어, "
              "일반인이 따라하면 위험한 절차를 찾아주세요. 애매하면 통과시키지 마세요. "
              "반드시 JSON 객체만 출력: {\"pass\": boolean, \"issues\": [문제 설명], \"needs_sources\": boolean}. "
              "needs_sources는 본문이 특정 차량에 적용되는 검증되지 않은 수치·토크·규격·교환주기 등 구체적 주장을 할 때만 true입니다. "
              "단순히 제조사 매뉴얼을 참고하라는 안내가 있거나 외부 검색 기능이 없다는 이유만으로 true로 표시하지 마세요. "
              "문제가 있으면 문제가 된 원문을 인용하여 구체적으로 설명하세요. "
              f"분야: {domain}. 분야별 지침: {DOMAIN_GUIDANCE.get(domain, '차종별 사용설명서 우선')}")
    result = client.responses.create(model="gpt-4.1-mini", instructions=prompt,
        input=f"주제: {topic}\n\n검토할 본문:\n{article}", max_output_tokens=1200)
    raw = result.output_text.strip()
    match = re.search(r"\{[\s\S]*\}", raw)
    if not match:
        raise ValueError("전문 검수 응답이 JSON이 아닙니다")
    data = json.loads(match.group())
    if not isinstance(data.get("pass"), bool) or not isinstance(data.get("issues"), list) or not isinstance(data.get("needs_sources"), bool):
        raise ValueError("전문 검수 결과 형식 오류")
    if not all(isinstance(x, str) and x.strip() for x in data["issues"]):
        raise ValueError("전문 검수 문제 목록 형식 오류")
    return data


def comprehensive_review(client, topic, article):
    static = validate_article(topic, article) + domain_static_checks(topic, article)
    expert = expert_review(client, topic, article)
    issues = list(dict.fromkeys(static + [str(x) for x in expert["issues"] if str(x).strip()]))
    if not expert["pass"] and not issues:
        issues.append("전문 검수에서 불합격했으나 상세 이유가 없어 수동 확인 필요")
    if expert["needs_sources"]:
        issues.append("본문의 구체적인 차종별 수치·규격·교환주기에 외부 근거 확인 필요 (자동 확인 불가)")
    return issues


def generate_article(client, topic):
    result = client.responses.create(
        model="gpt-4.1-mini",
        instructions=(
            "당신은 자동차 정비 실무를 아는 한국어 블로그 편집자입니다. "
            "주제에서 벗어나지 말고 실제 운전자가 따라 할 수 있는 정확한 정보성 글을 작성하세요. "
            "제목을 쓰지 말고 도입, 소제목 3~5개, 점검 순서와 주의사항, 간단한 결론을 포함해 약 1400~1900자로 작성하세요. "
            "마크다운 표, # 기호, 과도한 광고 문구, 불필요한 반복, 허구의 경험담, 근거 없는 통계는 금지합니다. "
            "자연스럽고 정확한 한국어 맞춤법과 띄어쓰기를 사용하세요. "
            + ARTICLE_STYLE_GUIDANCE +
            "차종별 점검법과 규격, 교환 주기는 제조사 매뉴얼을 우선하고 일률적인 수치나 시간을 단정하지 마세요. "
            "엔진오일은 차량별 점검 조건이 다르고 색깔만으로 교환 여부를 판단할 수 없으며, "
            "SAE J300 점도 등급을 설명할 때 W 앞 숫자는 저온 크랭킹·펌핑 성능 등급, W 뒤 숫자는 고온 점도 등급임을 정확히 구분하세요. "
            "5W를 특정 온도에서 무조건 잘 흐른다는 뜻으로 설명하지 마세요. 고점도가 무조건 엔진 보호에 유리하다고 말하지 마세요. "
            "0W-20, 5W-30, 5W-40을 비교할 때 차량 제조사 권장 SAE 점도와 API/ACEA/ILSAC 등 요구 성능 규격을 함께 확인하도록 안내하세요. "
            "특히 디젤 엔진오일은 금방 검어질 수 있다는 점을 고려하세요. "
            "상향등은 필요할 때만 사용하고 짙은 안개나 맞은편 차량 앞에서 무분별하게 사용하지 마세요. "
            "엔진오일 빨간 압력 경고등은 오일 교환 알림과 다릅니다. 주행 중 켜지면 가능한 한 빨리 안전하게 정차해 시동을 끄고, "
            "오일 보충이나 구매를 해결책으로 단정하지 말며 경고 지속 시 운행하지 않고 정비/견인을 안내하세요. "
            "과열 경고는 안전한 장소 정차를 우선하고, 뜨거운 냉각수 캡을 절대 열지 않도록 명확히 안내하세요. "
            "경고등 색상·의미·차종별 조치는 사용설명서를 우선하고, 진단 없이 원인을 단정하지 마세요. "
            "고압·고온·회전부·브레이크 등 위험 작업은 직접 수리를 권하지 말고 전문가 점검을 안내하세요. "
            "자동차 부품을 범용이라고 단정하지 말고 차종별 호환성을 강조하세요. "
            "확인할 수 없는 제품 효능이나 가격, 할인율을 언급하지 마세요. "
            "글에 광고 링크나 사진 삽입 지시를 쓰지 마세요."
        ),
        input=(f"글 주제: {topic}\n전문 분야: {classify_domain(topic)}\n위험도: {topic_safety_tier(topic)}\n"
               f"전문 기준: {DOMAIN_GUIDANCE.get(classify_domain(topic), '제조사 사용설명서 우선')}\n"
               "독자가 실제 점검에 활용할 수 있는 글을 작성하세요. 확인 불가능한 숫자나 규격은 만들지 마세요."),
        max_output_tokens=3300,
    )
    article = remove_repeated_heading(clean_blog_body(result.output_text.strip()), make_clean_title(topic), topic)
    if len(article) < 500:
        raise RuntimeError("생성 원고가 너무 짧거나 비어 있어 저장하지 않습니다.")
    return article


def revise_article_for_safety(client, topic, article, issues):
    """유료 1회 수정 시도. 원문 안전 문제를 보수적으로 바로잡습니다."""
    response = client.responses.create(
        model="gpt-4.1-mini",
        instructions=(
            "당신은 한국어 자동차 안전 편집자입니다. 기존 원고를 전면 교체하지 말고 지적된 안전·품질·문체 문제를 수정하세요. 문체 지적이 있으면 본문 전체의 종결과 문장 연결을 자연스러운 해요체로 다듬으세요. "
            + ARTICLE_STYLE_GUIDANCE +
            "제조사 규격이나 외부 근거를 확인할 수 없으면 수치와 단정을 삭제하고 매뉴얼 확인을 안내하세요. "
            "빨간 오일 압력 경고 시 즉시 안전 정차 후 시동 정지, 탑승자 안전 확보, 긴급출동/견인을 강조하세요. "
            "오일 보충 또는 경고등 소등만으로 재주행이 안전하다고 말하지 마세요. "
            "오일 딥스틱은 오일량 확인 도구이지 정확한 점도 측정기가 아닙니다. "
            "과열 시 뜨거운 냉각계통 캡을 열지 않도록 설명하세요. "
            "차종별 차이는 매뉴얼 우선. 제목·광고·사진 표시는 작성하지 마세요. 수정된 본문만 출력하세요."
        ),
        input=f"분야별 기준: {DOMAIN_GUIDANCE.get(classify_domain(topic), '차량 매뉴얼 우선')}\n주제: {topic}\n수정할 문제: {json.dumps(issues, ensure_ascii=False)}\n\n기존 원고:\n{article}",
        max_output_tokens=3300,
    )
    revised = remove_repeated_heading(clean_blog_body(response.output_text.strip()), make_clean_title(topic), topic)
    if len(revised) < 700:
        raise RuntimeError("수정 원고가 너무 짧아 원문을 보존합니다")
    return revised


def offline_topic_audit():
    """기본 생성 계획의 주제를 외부 호출 없이 일괄 검사. 주제 이력 변경 없음."""
    history = load_history()
    existing = load_existing_titles()
    remaining = select_topics(history, len(TOPICS), existing)
    rows = []
    for topic, keyword in remaining:
        domain = classify_domain(topic)
        tier = topic_safety_tier(topic)
        image = make_image_jobs(topic, keyword)[0]["queries"][0]
        flags = []
        if domain == "일반 자동차 관리":
            flags.append("전문 분야 매핑 확인")
        if image in ("passenger car exterior", "car engine bay", "car interior dashboard", "car tire tread wheel", "car detailing cleaning"):
            flags.append("사진 검색어 구체화 권장")
        if not is_no_affiliate_topic(topic) and any(x in topic for x in ("경고", "이상", "고장", "누출", "화재", "과열", "누유")):
            flags.append("상품 추천 적합성 수동 확인")
        rows.append({"topic": topic, "domain": domain, "risk": tier,
                     "affiliate": product_keyword_for_topic(topic, keyword), "image_query": image,
                     "flags": flags})
    report = {"total_topics": len(TOPICS), "remaining": len(rows),
              "flagged": sum(bool(r["flags"]) for r in rows), "topics": rows,
              "note": "오프라인 규칙 점검만 수행; 기술 사실관계·사진 실제 적합성·상품 호환성 검증 아님"}
    path = BASE_DIR / "topic_audit.json"
    path.parent.mkdir(parents=True, exist_ok=True)
    path.write_text(json.dumps(report, ensure_ascii=False, indent=2), encoding="utf-8")
    print(f"[무료 일괄 진단] 남은 주제 {len(rows)}개 / 점검 권장 {report['flagged']}개")
    print("진단 파일:", path)
    for row in [r for r in rows if r["flags"]][:15]:
        print("-", row["topic"], "|", ", ".join(row["flags"]))
    if report["flagged"] > 15:
        print(f"... 나머지 {report['flagged'] - 15}개는 topic_audit.json에서 확인")
    return report


def review_with_revisions(client, topic, article):
    """검수 실패는 예외나 빈 응답도 포함해 fail-closed 처리."""
    log = []
    for attempt in range(MAX_REVISIONS + 1):
        try:
            issues = comprehensive_review(client, topic, article)
        except Exception as exc:
            issues = [f"검수 실행 실패: {type(exc).__name__}"]
            log.append({"round": attempt, "issues": issues})
            return article, issues, log
        log.append({"round": attempt, "issues": issues})
        if not issues:
            return article, [], log
        if attempt == MAX_REVISIONS:
            return article, issues, log
        try:
            article = revise_article_for_safety(client, topic, article, issues)
        except Exception as exc:
            issues.append(f"자동 수정 실패: {type(exc).__name__}")
            return article, issues, log
    return article, ["검수 완료 여부 불명"], log


def generate_one(topic, keyword, history):
    run_dir = BASE_DIR / "output" / datetime.now().strftime("%Y%m%d_%H%M%S_%f")
    image_dir = run_dir / "images"
    image_dir.mkdir(parents=True, exist_ok=True)
    print("GPT 원고 작성 및 전문 검수 중...")
    try:
        client = OpenAI(api_key=OPENAI_KEY, max_retries=0, timeout=120)
        article = generate_article(client, topic)
    except Exception as exc:
        (run_dir/'review_report.json').write_text(json.dumps({
            'topic':topic, 'status':'ERROR', 'stage':'generation',
            'issues':['원고 생성 실패: '+type(exc).__name__]},ensure_ascii=False,indent=2),encoding='utf-8')
        print('원고 생성 실패:',type(exc).__name__)
        return False
    (run_dir/'draft_original.txt').write_text(article,encoding='utf-8-sig')
    article, warnings, review_log = review_with_revisions(client, topic, article)
    (run_dir/'draft_reviewed.txt').write_text(article,encoding='utf-8-sig')
    report = {"topic": topic, "domain": classify_domain(topic),
              "risk": topic_safety_tier(topic), "status": "HOLD" if warnings else "REVIEW_CANDIDATE",
              "issues": warnings, "review_rounds": review_log,
              "caveat": "AI 자동 검수 통과는 사실 검증 또는 발행 승인과 다릅니다."}
    (run_dir / "review_report.json").write_text(json.dumps(report, ensure_ascii=False, indent=2), encoding="utf-8")
    if warnings:
        print("[발행 보류] 검수 문제:", "; ".join(warnings))
        (run_dir / "blog_post.txt").write_text(
            "[발행 보류 — 게시 금지]\n" + "\n".join("• " + w for w in warnings)
            + "\n\n" + make_clean_title(topic) + "\n\n" + article, encoding="utf-8-sig")
        print("원고 보관:", run_dir)
        return False
    print("[자동 검수 통과 후보] 발행 전 최종 육안 확인 필요")
    product = None
    if is_no_affiliate_topic(topic):
        print("안전 주제: 쿠팡 추천 제외")
    else:
        try:
            product = product_search_with_safe_fallback(product_keyword_for_topic(topic, keyword))
        except Exception as exc:
            print("쿠팡 검색 생략:", type(exc).__name__)
    # Save the draft immediately, even if image APIs fail later.
    (run_dir / "blog_post.txt").write_text(
        build_blog_post(topic, article, product, available_images=[]), encoding="utf-8-sig"
    )
    photo_sources = []
    image_checks = []
    if product:
        try:
            if not save_product_image(product, image_dir):
                print("상품 이미지가 없어 본문에 사진 3 표시를 생략합니다.")
        except Exception as exc:
            print("상품 이미지 저장 실패:", type(exc).__name__)

    used_ids = set()
    for job in make_image_jobs(topic, keyword):
        chosen = None
        try:
            chosen = save_pixabay_image(client, job, image_dir, used_ids)
        except Exception as exc:
            print("Pixabay 오류:", type(exc).__name__)
        if not chosen:
            for provider in ("Openverse", "Wikimedia Commons"):
                try:
                    chosen = save_open_photo(client, job, image_dir, used_ids, provider)
                except Exception as exc:
                    print(provider, "오류:", type(exc).__name__)
                if chosen:
                    break
        image_checks.append({'job':job['name'], 'photo_search':'saved' if chosen else 'no_match'})
        if chosen:
            photo_sources.append(chosen)
        else:
            if is_urgent_warning_topic(topic):
                print("경고등 이미지가 없어도 가짜 경고등 AI 이미지는 생성하지 않습니다:", job["name"])
                continue
            if not ALLOW_PAID_AI_IMAGES:
                print(f"무료 사진 없음 ({job['name']}) → 유료 AI 이미지 생략 (기본 설정)")
                continue
            print(f"무료 사진 없음 ({job['name']}) → 유료 AI 이미지 생성")
            path = image_dir / (job["name"] + "_AI.png")
            try:
                generate_ai_image(client, job["prompt"], path)
                try:
                    approved = check_ai_generated_image(client, path, job)
                except Exception:
                    approved = False
                if not approved:
                    path.unlink(missing_ok=True)
                    print("AI 사진 검증 실패: 삭제함")
            except Exception as exc:
                path.unlink(missing_ok=True)
                print("AI 사진 생성 실패:", type(exc).__name__)

    images = list(image_dir.iterdir())
    if product and not any(p.stem == "coupang_product" or p.stem.startswith("coupang_product_") for p in images):
        # 실제 상품 사진이 없으면 상품 소개도 제외 (마커/가격/링크 정합성 유지)
        product = None
    if not images:
        image_dir.rmdir()
    # The ONLY article file; markers are inside the article.
    article_path = run_dir / "blog_post.txt"
    article_path.write_text(build_blog_post(topic, article, product, photo_sources, images), encoding="utf-8-sig")
    report['photo_sources'] = photo_sources
    report['image_checks'] = image_checks
    report['saved_images'] = [p.name for p in images]
    (run_dir/'review_report.json').write_text(json.dumps(report,ensure_ascii=False,indent=2),encoding='utf-8')
    history.append(topic)
    save_history(history)
    print("[검수 통과 후보] 자동 검수 통과는 사실 정확성 보증이 아닙니다.")
    print("원고 및 이미지 저장 완료:", run_dir)
    print("결과물: blog_post.txt + review_report.json + 확보된 사진")
    return True

def main():
    print("\n=== 세차연구소 AI 검수 통합판 ===")
    print("115개 이상 전체 주제 무료 진단은 A 입력 (API 비용 0원)")
    first = input("전체 진단 A / 글 생성 Enter / 취소 0: ").strip().upper()
    if first == "A":
        offline_topic_audit()
        return
    if first == "0":
        return
    while True:
        raw = input("이번 실행에서 만들 글 개수 (1~20, 취소는 0): ").strip()
        if raw == "0":
            print("취소했습니다.")
            return
        if raw.isdecimal() and 1 <= int(raw) <= 20:
            count = int(raw)
            break
        print("1부터 20 사이의 숫자를 입력하세요.")

    history = load_history()
    existing_titles = load_existing_titles()
    remaining = select_topics(history, len(TOPICS), existing_titles, include_failed='--retry-failed' in sys.argv)
    print(f"전체 준비 주제: {len(TOPICS)}개")
    print(f"기존 게시물 제목 등록: {len(existing_titles)}개 / 중복 제외: {len(TOPICS) - len(remaining)}개 (작성 이력·기존 검수 보고서 포함)")
    print(f"\n사용 가능한 새 주제: {len(remaining)}개 / 요청: {count}개")
    if count > len(remaining):
        print("남은 주제가 부족합니다. 주제를 추가하거나 요청 개수를 줄이세요.")
        return
    mode = input("무료 테스트는 T, 실제 유료 생성은 G (취소는 0): ").strip().upper()
    if mode == "T":
        print("\n[무료 테스트] 외부 API 호출 없음 / 글·이미지 생성 없음 / 이력 변경 없음")
        for i, (topic, keyword) in enumerate(remaining[:count], 1):
            print(f"{i}. {topic} | 분야: {classify_domain(topic)} | 위험도: {topic_safety_tier(topic)} | 쿠팡 검색어: {product_keyword_for_topic(topic, keyword)}")
            print("   사진 검색어:", make_image_jobs(topic, keyword)[0]["queries"][0])
        return
    if mode != "G":
        print("취소했습니다. API 호출 없음")
        return
    if not OPENAI_KEY:
        print(".env 파일의 OPENAI_API_KEY를 확인하세요. 실행을 중단합니다.")
        return
    confirm = input("OpenAI 글 작성·검수·이미지 판독에 요금이 발생합니다 (AI 이미지 생성은 기본 OFF). 진행하려면 YES 입력: ").strip().upper()
    if confirm != "YES":
        print("취소했습니다. API 호출 없음")
        return
    successes = 0
    for index, (topic, keyword) in enumerate(remaining[:count], 1):
        print(f"\n===== {index}/{count}번째 글 생성 =====")
        try:
            if generate_one(topic, keyword, history):
                successes += 1
        except (KeyboardInterrupt, EOFError):
            print("\n사용자가 작업을 중단했습니다.")
            break
        except Exception as exc:
            print(f"{index}번째 글 생성 실패: {type(exc).__name__}")
            print("다음 글을 계속 진행합니다.")
    print(f"\n생성 작업 종료: {successes}/{count}회 정상 처리")
    print("저장 위치:", BASE_DIR / "output")
    print("주제 중복 방지 기록:", HISTORY_PATH)


if __name__ == "__main__":
    main()
