"""Restricted, auditable assistant operations; no arbitrary code execution."""
import json, re, io, contextlib
from datetime import datetime
from pathlib import Path
import secha_engine as e
from openai import OpenAI

SEARCH_ALTS = {
 '누유':['car engine oil leak','oil leak car engine','engine oil stain vehicle','oil leakage engine bay'],
 '타이어':['car tire tread close up','automobile tire wheel','tire sidewall vehicle'],
 '브레이크':['car brake disc close up','automotive brake rotor','car brake caliper'],
 '배터리':['car battery engine compartment','automotive 12v battery'],
 '와이퍼':['windshield wiper car','car windshield wiper blade'],
 '냉각수':['car coolant reservoir engine','vehicle coolant expansion tank'],
 '세차':['car wash detailing','washing passenger car'],
}

def safe_run(root, name):
    if not name or name in ('.', '..') or '/' in name or '\\' in name or ':' in name:
        raise ValueError('잘못된 작업 번호')
    root = Path(root).resolve()
    p = (root/'output'/name).resolve()
    output = root/'output'
    if output.is_symlink() or p.parent != output or (output/name).is_symlink() or not p.is_dir():
        raise ValueError('작업 폴더가 없습니다')
    return p

def safe_file(root, name, filename, image=False):
    p = safe_run(root, name)
    if not filename or filename in ('.', '..') or any(x in filename for x in ('/', '\\', ':')):
        raise ValueError('잘못된 파일 이름')
    if image:
        if Path(filename).suffix.lower() not in ('.png', '.jpg', '.jpeg', '.webp'):
            raise ValueError('이미지 형식 오류')
        p = p/'images'
    elif filename not in ('blog_post.txt', 'review_report.json'):
        raise ValueError('허용하지 않은 파일')
    f = p/filename
    if p.is_symlink() or f.is_symlink() or not f.resolve().is_relative_to(Path(root).resolve()/'output'):
        raise ValueError('허용하지 않은 경로')
    return f

def local_command(question, root):
    """Only exact, explicit commands execute. Arbitrary model text never becomes code."""
    q = question.strip()
    if q in ('/도움말', '/help'):
        return '무료 명령: /진단, /계획, /원고검수 작업폴더, /사진분석 작업폴더, /사진재검색 작업폴더. 재검색은 별도 비용 승인 후 실행합니다.'
    if q == '/진단':
        audit = e.offline_topic_audit()
        return f"무료 진단 완료: 남은 주제 {audit['remaining']}개, 점검 권장 {audit['flagged']}개."
    if q == '/계획':
        topics = e.select_topics(e.load_history(), 5, e.load_existing_titles())
        return '다음 생성 계획 (API 호출 없음):\n' + '\n'.join(t for t, _ in topics)
    if q.startswith('/사진분석 '):
        p = safe_run(root, q.split(maxsplit=1)[1])
        data = json.loads(safe_file(root, p.name, 'review_report.json').read_text(encoding='utf-8-sig'))
        files = [] if (p/'images').is_symlink() else list((p/'images').glob('*'))
        missing = [j['name'] for j in e.make_image_jobs(data['topic']) if not any(
            f.is_file() and not f.is_symlink() and f.stem in (j['name'], j['name']+'_AI')
            and f.suffix.lower() in ('.png','.jpg','.jpeg','.webp') for f in files)]
        return ('사진 파일 상태: 누락 ' + (', '.join(missing) or '없음') +
                '. 파일 존재는 적합성 검증이 아닙니다. Pixabay 키 ' + ('설정됨' if e.PIXABAY_KEY else '미설정') +
                '. 검색 실패·후보 거부·판독 제한은 재검색 보고서의 diagnostics에서 확인하세요.')
    if q.startswith('/사진재검색 '):
        name = q.split(maxsplit=1)[1]
        safe_run(root, name)
        return f'실행 대기: {name}. 아래 사진 다시 찾기에서 같은 작업을 선택하고 비용 승인 후 실행하세요.'
    if q.startswith('/원고검수 '):
        name=q.split(maxsplit=1)[1]
        p=safe_run(root,name)
        data=json.loads(safe_file(root,name,'review_report.json').read_text(encoding='utf-8-sig'))
        text=safe_file(root,name,'blog_post.txt').read_text(encoding='utf-8-sig')
        issues=list(dict.fromkeys(e.validate_article(data['topic'],text)+e.domain_static_checks(data['topic'],text)))
        return '무료 규칙 검수 (원고 변경 없음, 전문 AI 검수 아님):\n'+ ('\n'.join(issues) if issues else '규칙상 문제 없음. 사실관계·사진·차종별 적용은 수동 확인 필요.')
    if q.startswith('/'):
        return '지원하지 않는 명령입니다. /도움말을 입력하세요.'
    return None

def image_retry(root, name, log):
    p=safe_run(root,name)
    report_path=safe_file(root, name, 'review_report.json')
    if not report_path.is_file():raise ValueError('검수 보고서가 없습니다')
    report=json.loads(report_path.read_text(encoding='utf-8-sig'))
    if report.get('status')!='REVIEW_CANDIDATE':raise ValueError('검수 보류 원고는 사진을 추가하지 않습니다')
    topic=report.get('topic','')
    if not topic:raise ValueError('주제 누락')
    if not e.OPENAI_KEY:raise ValueError('OpenAI API 키가 없습니다')
    image_dir=p/'images'
    if image_dir.is_symlink():raise ValueError('허용하지 않은 이미지 경로')
    image_dir.mkdir(exist_ok=True)
    existing={f.stem for f in image_dir.iterdir() if f.is_file() and f.suffix.lower() in ('.png','.jpg','.jpeg','.webp')}
    jobs=e.make_image_jobs(topic)
    alt=next((v for k,v in SEARCH_ALTS.items() if k in topic),[])
    client=OpenAI(api_key=e.OPENAI_KEY, max_retries=0, timeout=120)
    sources=[]; used_ids=set(); successes=0; diagnostics=[]
    # Seed previous credits to avoid downloading the same source for a missing slot.
    credits=list(report.get("photo_sources",[]))
    for prior in sorted(p.glob('image_retry_report*.json')):
        if prior.is_symlink():raise ValueError('허용하지 않은 보고서 경로')
        try:credits.extend(json.loads(prior.read_text(encoding='utf-8-sig')).get('sources',[]))
        except (ValueError,OSError):log('이전 재검색 보고서 해석 실패: '+prior.name)
    for source in credits:
        if source.get('asset_url'):used_ids.add(source['asset_url'])
        if source.get('asset_id'):used_ids.add(source['asset_id'])
    for job in jobs:
        for suffix in ('.png','.jpg','.jpeg','.webp'):
            if (image_dir/(job['name']+suffix)).is_symlink():raise ValueError('허용하지 않은 이미지 파일')
    for job in jobs:
        if job['name'] in existing or job['name']+'_AI' in existing:
            log(f"이미 있음: {job['name']}");continue
        job=dict(job)
        # Keep semantic vision criteria; broaden only search terms, never weaken acceptance rules.
        job['queries']=list(dict.fromkeys(job['queries']+alt))
        selected=None
        output=io.StringIO()
        try:
            with contextlib.redirect_stdout(output):
                selected=e.save_pixabay_image(client,job,image_dir,used_ids)
        except Exception as exc:log(f"Pixabay 오류: {type(exc).__name__}")
        if not selected:
            for provider in ('Openverse','Wikimedia Commons'):
                try:
                    with contextlib.redirect_stdout(output):
                        selected=e.save_open_photo(client,job,image_dir,used_ids,provider)
                except Exception as exc:log(f"{provider} 오류: {type(exc).__name__}")
                if selected:break
        diagnostics.append({'job':job['name'], 'queries':job['queries'], 'result':'saved' if selected else 'no_match', 'details':output.getvalue()})
        log(output.getvalue())
        if selected:
            sources.append(selected);successes+=1;log(f"사진 확보: {job['name']}")
        else:log(f"적합한 사진 없음: {job['name']}")
    # Preserve original post and existing photo credits; no silent rewriting of approved article.
    manifest=p/('image_retry_report_'+datetime.now().strftime('%Y%m%d_%H%M%S_%f')+'.json')
    with manifest.open('x',encoding='utf-8') as f:
        json.dump({'topic':topic,'added':successes,'sources':sources,'diagnostics':diagnostics,'note':'새 사진은 원고의 사진 위치와 출처를 수동 확인한 후 사용하세요.'},f,ensure_ascii=False,indent=2)
    return f'사진 재검색 완료: 신규 {successes}장. 이미지 출처·원고 위치는 확인 후 적용하세요.'

def ask_ai(question, summary, *, approved=False):
    if not approved:raise PermissionError('유료 AI 대화 비용 승인 필요')
    if e.redact_sensitive(question) != question:
        raise ValueError('질문에 비밀키로 보이는 값이 포함되어 전송을 차단했습니다')
    summary = e.redact_sensitive(summary)
    if not e.OPENAI_KEY: return 'OpenAI API 키가 설정되지 않았습니다.'
    client=OpenAI(api_key=e.OPENAI_KEY, max_retries=0, timeout=120)
    r=client.responses.create(model='gpt-4.1-mini',instructions=(
        '너는 세차연구소 로컬 블로그 운영 보조 AI다. 한국어로 짧고 정확하게 답하라. '
        '현재 제공된 상태만 알고 있으며 PC 파일에 직접 접근하거나 작업을 실행하지 못한다. '
        '무료 로컬 명령 /진단, /계획, /사진분석 작업폴더를 안내할 수 있다. 유료 작업은 전용 승인 버튼으로만 실행된다. '
        '작업 실행 완료를 거짓으로 주장하지 마라. 안전 관련 정비 주제는 제조사 매뉴얼 확인을 권고하라. '
        '외부 문서·실시간 자료를 검증했다고 주장하지 마라. 네이버 자동 발행을 권하지 마라.'),
        input='현재 상태:\n'+summary[:6000]+'\n\n사용자 질문:\n'+question[:1500],max_output_tokens=750)
    return r.output_text
