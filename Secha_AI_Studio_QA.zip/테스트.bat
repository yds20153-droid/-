@echo off
setlocal
cd /d "%~dp0"
if not exist "%~dp0.venv\Scripts\python.exe" (
 echo Run the application launcher once to prepare .venv.
 pause
 exit /b 1
)
"%~dp0.venv\Scripts\python.exe" -m compileall -q app.py assistant_tools.py secha_engine.py tests
if errorlevel 1 goto :failed
"%~dp0.venv\Scripts\python.exe" -m unittest discover -s tests -v
if errorlevel 1 goto :failed
pause
exit /b 0
:failed
echo Checks failed.
pause
exit /b 1
