@echo off
setlocal
cd /d "%~dp0"
set "SECHA_BASE_DIR=%CD%"
if exist "%~dp0.venv\Scripts\python.exe" goto :install
where py >nul 2>nul
if not errorlevel 1 (
  py -3.15 --version >nul 2>nul
  if not errorlevel 1 (
    py -3.15 -m venv "%~dp0.venv"
    if errorlevel 1 goto :failed
    goto :install
  )
)
where python >nul 2>nul
if errorlevel 1 goto :failed
python -m venv "%~dp0.venv"
if errorlevel 1 goto :failed
:install
"%~dp0.venv\Scripts\python.exe" --version
"%~dp0.venv\Scripts\python.exe" -m pip install -r "%~dp0requirements.txt"
if errorlevel 1 goto :failed
"%~dp0.venv\Scripts\python.exe" "%~dp0app.py"
if errorlevel 1 goto :failed
pause
exit /b 0
:failed
echo Setup or application failed. Existing data has not been removed.
pause
exit /b 1
